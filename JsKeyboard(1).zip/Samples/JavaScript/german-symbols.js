﻿var layoutDefDe =
{
	width: 295,
	height: 110,
	keys:
[{
	code: 132,
	type: "regular",
	content: "’",
	left: 55,
	top: 10,
	width: 40,
	height: 40
},
	{
		code: 132,
		type: "regular",
		content: "€",
		left: 10,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 132,
		type: "regular",
		content: "„",
		left: 100,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 132,
		type: "regular",
		content: "”",
		left: 145,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 132,
		type: "regular",
		content: "« ",
		left: 190,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 132,
		type: "regular",
		content: " »",
		left: 235,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 132,
		type: "regular",
		content: " –",
		left: 191,
		top: 54,
		width: 40,
		height: 40
	},
	{
		code: 132,
		type: "regular",
		content: "—",
		left: 236,
		top: 54,
		width: 40,
		height: 40
	},
	{
		code: 0,
		type: "regular",
		content: "ä",
		left: 10,
		top: 55,
		width: 39,
		height: 40
	},
	{
		code: 132,
		type: "regular",
		content: "ö",
		left: 57,
		top: 55,
		width: 40,
		height: 40
	},
	{
		code: 132,
		type: "regular",
		content: "ü",
		left: 102,
		top: 55,
		width: 40,
		height: 40
	},
	{
		code: 132,
		type: "regular",
		content: "ß",
		left: 147,
		top: 55,
		width: 40,
		height: 40
	}
]
};