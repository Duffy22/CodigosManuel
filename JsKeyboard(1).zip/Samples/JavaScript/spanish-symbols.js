﻿var layoutDefEs =
{
	width: 430,
	height: 110,
	keys:
[{
	code: 162,
	type: "regular",
	content: "’",
	left: 55,
	top: 10,
	width: 40,
	height: 40
},
	{
		code: 162,
		type: "regular",
		content: "€",
		left: 10,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "“",
		left: 100,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "”",
		left: 145,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "« ",
		left: 190,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: " »",
		left: 235,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: " –",
		left: 280,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "—",
		left: 325,
		top: 10,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "á ",
		left: 10,
		top: 55,
		width: 39,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "é",
		left: 57,
		top: 55,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "í",
		left: 102,
		top: 55,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "ñ",
		left: 147,
		top: 55,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "ó",
		left: 192,
		top: 55,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "ú",
		left: 237,
		top: 55,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "ü",
		left: 282,
		top: 55,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "¿",
		left: 327,
		top: 55,
		width: 40,
		height: 40
	},
	{
		code: 162,
		type: "regular",
		content: "¡",
		left: 372,
		top: 55,
		width: 40,
		height: 40
	}
]
};