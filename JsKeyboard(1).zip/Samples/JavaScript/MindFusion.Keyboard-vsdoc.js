MindFusion = {
	Common: {
		Collections: {
			IEnumerable: function (items) {
				/// <summary>Represents an array of arbitrary objects.</summary>
				/// <param name="items" type="Array" optional="true">Optional. Type: Array&#10;Array. The underlying array data structure of the collection.</param>
			},
			List: function (items) {
				/// <summary>Represents an array of arbitrary objects.</summary>
				/// <param name="items" type="Array" optional="true">Optional. Type: Array&#10;Array. The underlying array data structure of the list.</param>
			},
			ObservableCollection: function (items) {
				/// <summary>Represents a collection of arbitrary objects.</summary>
				/// <param name="items" type="Array" optional="true">Optional. Type: Array&#10;Array. The underlying array data structure of the collection.</param>
				/// <field name="collectionChanged" type="EventDispatcher">Occurs when an item is added, removed, changed, moved, or the entire list is refreshed. Syntax: collectionChanged.addEventListener( function(sender, args){} );</field>
				/// <field name="collectionChanging" type="EventDispatcher">Occurs just before an item is added, removed, changed, moved, or the entire list is refreshed. Syntax: collectionChanging.addEventListener( function(sender, args){} );</field>
			},
			__namespace: true
		},
		UI: {
			Calendar: function (element) {
				/// <summary>Represents a month calendar.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="date" type="Date">Gets the date of this calendar.</field>
				/// <field name="formatInfo" type="MindFusion.Common.UI.DateSettings">Gets the DateSettings object used to format and display date and time information in the calendar.</field>
				/// <field name="locale" type="MindFusion.Common.UI.Locale">Gets or sets the locale object used to format and display localizable information in the calendar.</field>
				/// <field name="maxSpan" type="MindFusion.Common.UI.TimeUnit">Gets or sets the maximum date-time span of the calendar.</field>
				/// <field name="minSpan" type="MindFusion.Common.UI.TimeUnit">Gets or sets the minimum date-time span of the calendar.</field>
				/// <field name="span" type="MindFusion.Common.UI.TimeUnit">Gets or sets the current date-time span of the calendar.</field>
				/// <field name="view" type="MindFusion.Common.UI.DateTimeView">Gets the current calendar view.</field>
				/// <field name="selectedDateChanged" type="EventDispatcher">Raised when the selected date is changed. Syntax: selectedDateChanged.addEventListener( function(sender, args){} );</field>
				/// <field name="selectedDateChanging" type="EventDispatcher">Raised when the selected date is changing. Syntax: selectedDateChanging.addEventListener( function(sender, args){} );</field>
				/// <field name="viewChanged" type="EventDispatcher">Raised when the selected view is changed. Syntax: viewChanged.addEventListener( function(sender, args){} );</field>
			},
			ConfirmDialog: function (title, message, parent) {
				/// <summary>Represents a modal dialog box with OK and Cancel buttons.</summary>
				/// <param name="title" type="String" optional="true">Optional. String. The text to display as a dialog title.</param>
				/// <param name="message" type="String" optional="true">Optional. String. The message to display as the dialog text.</param>
				/// <param name="parent" type="HTMLElement" optional="true">Optional. HTMLElement. The Dom element to append the dialog to.If the parameter is not specified, the dialog will be appended to document.body.</param>
				/// <field name="host" type="MindFusion.Common.UI.Container">Gets the host of this WindowHost. Inherited from WindowBase.</field>
				/// <field name="navigateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded in the control's content IFrame. Inherited from WindowBase.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the content template. Inherited from WindowBase.</field>
				/// <field name="templateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded as a control content template. Inherited from WindowBase.</field>
				/// <field name="windowState" type="MindFusion.Common.UI.WindowState">Gets or sets the state of this Window. Inherited from WindowBase.</field>
				/// <field name="allowClose" type="Boolean">Gets or sets a value indicating whether this Window can be closed. Inherited from Window.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets a value indicating whether this Window can be dragged. Inherited from Window.</field>
				/// <field name="allowMaximize" type="Boolean">Gets or sets a value indicating whether this Window can be maximized. Inherited from Window.</field>
				/// <field name="allowMinimize" type="Boolean">Gets or sets a value indicating whether this Window can be minimized. Inherited from Window.</field>
				/// <field name="allowPin" type="Boolean">Gets or sets a value indicating whether this Window can be pinned. Inherited from Window.</field>
				/// <field name="allowRefresh" type="Boolean">Gets or sets a value indicating whether this Window can be refreshed. Inherited from Window.</field>
				/// <field name="allowResize" type="Boolean">Gets or sets a value indicating whether this Window can be resized. Inherited from Window.</field>
				/// <field name="footer" type="HTMLDivElement">Gets a reference to the Window footer DOM element. Inherited from Window.</field>
				/// <field name="header" type="HTMLDivElement">Gets a reference to the Window header DOM element. Inherited from Window.</field>
				/// <field name="iconSrc" type="String">Gets or sets the url of the title icon. Inherited from Window.</field>
				/// <field name="minHeight" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed height of this Window. Inherited from Window.</field>
				/// <field name="minWidth" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed width of this Window. Inherited from Window.</field>
				/// <field name="modal" type="Boolean">Gets or sets a value indicating whether this Window should be modal. Inherited from Window.</field>
				/// <field name="pinned" type="Boolean">Gets or sets a value, indicating whether this Window is pinned. Inherited from Window.</field>
				/// <field name="title" type="String">Gets or sets the title of this Window. Inherited from Window.</field>
				/// <field name="useFrameTitle" type="Boolean">Gets or sets a value indicating whether the window will display the title of its content iframe. Inherited from Window.</field>
				/// <field name="contentLoad" type="EventDispatcher">Raised when the windows's contents are loaded. Syntax: contentLoad.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanged" type="EventDispatcher">Raised when the window's state is changed. Syntax: stateChanged.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanging" type="EventDispatcher">Raised when the window's state is changing. Syntax: stateChanging.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClose" type="EventDispatcher">Raised when the Window is closed. Syntax: windowClose.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClosing" type="EventDispatcher">Raised when the Window is closing. Syntax: windowClosing.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpen" type="EventDispatcher">Raised when the Window is opened. Syntax: windowOpen.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpening" type="EventDispatcher">Raised when the Window is opening. Syntax: windowOpening.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip of the Window&#160;is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="dragEnd" type="EventDispatcher">Raised when drag operation is finished. Syntax: dragEnd.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="dragStart" type="EventDispatcher">Raised when a drag operation is started. Syntax: dragStart.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="headerClick" type="EventDispatcher">Raised when the Window header is clicked. Syntax: headerClick.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="resizeEnd" type="EventDispatcher">Raised when a resize operation is finished. Syntax: resizeEnd.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="resizeStart" type="EventDispatcher">Raised when a resize operation is started. Syntax: resizeStart.addEventListener( function(sender, args){} ); Inherited from Window.</field>
			},
			Container: function (element) {
				/// <summary>A base class for UI container controls.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="activeChild" type="MindFusion.Common.UI.WindowBase">Gets the topmost child window.</field>
				/// <field name="children" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of child windows.</field>
				/// <field name="content" type="HTMLDivElement">Gets a reference to the container's content element.</field>
				/// <field name="contentBounds" type="MindFusion.Common.UI.Rect">Gets the bounds of this container's content element.</field>
				/// <field name="contentRect" type="MindFusion.Common.UI.Rect">Gets the bounding rect of this container's content element.</field>
			},
			ControlModifiedEventArgs: function (control, changes) {
				/// <summary>Specifies data for notification events, related to control changes.</summary>
				/// <param name="control" type="Control">Control. The control that is being modified</param>
				/// <param name="changes" type="Object">Object. An object containing the changed properties.</param>
				/// <field name="changes" type="Object">Gets the changed properties of the control, associated with the event.</field>
				/// <field name="control" type="MindFusion.Common.UI.Control">Gets the control that is modified.</field>
			},
			ControlModifyingEventArgs: function (control, changes) {
				/// <summary>Specifies data for validation events, related to control changes.</summary>
				/// <param name="control" type="Control">Control. The control that is being modified</param>
				/// <param name="changes" type="Object">Object. An object containing the changed properties.</param>
				/// <field name="changes" type="Object">Gets the changed properties of the control, associated with the event.</field>
				/// <field name="control" type="MindFusion.Common.UI.Control">Gets the control that is being modified.</field>
			},
			DateTimePicker: function (element) {
				/// <summary>Represents an input control with the ability to parse and select dates from a popup calendar and/or time from a popup list.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="autoComplete" type="Boolean">Gets or sets a value indicating whether the control will try to parse incomplete input.</field>
				/// <field name="datePartSelect" type="Boolean">Gets or sets a value indicating whether date part selection is enabled.</field>
				/// <field name="format" type="String">Gets the formatting of the date-time value displayed in the control.</field>
				/// <field name="interval" type="Number">Gets or sets the time interval.</field>
				/// <field name="locale" type="MindFusion.Common.UI.Locale">Gets or sets the locale object used to format and display dates.</field>
				/// <field name="maxTime" type="Number">Gets or sets the maximum time value, displayed in the DateTimePicker:</field>
				/// <field name="minTime" type="Number">Gets or sets the minimum time value, displayed by the DateTimePicker.</field>
				/// <field name="mode" type="MindFusion.Common.UI.DateTimePickerMode">Gets or sets the mode of the control.</field>
				/// <field name="allowEmptyInput" type="Boolean">Gets or sets a value indicating whether empty input is considered valid. Inherited from Picker.</field>
				/// <field name="buttonStyle" type="MindFusion.Common.UI.PickerButtonStyle">Gets or sets a value indicating the display mode of the dropdown button. Inherited from Picker.</field>
				/// <field name="clearButtonStyle" type="MindFusion.Common.UI.PickerButtonStyle">Gets or sets a value indicating the display mode of the clear button. Inherited from Picker.</field>
				/// <field name="createWrapper" type="Boolean">Gets or sets a value indicating whether a wrapper div element should be created for the control. Inherited from Picker.</field>
				/// <field name="dropdownHeight" type="MindFusion.Common.UI.Unit">Gets or sets the height of the dropdown. Inherited from Picker.</field>
				/// <field name="dropdownOffset" type="MindFusion.Common.UI.Point">Gets or sets the offset of the dropdown. Inherited from Picker.</field>
				/// <field name="dropdownWidth" type="MindFusion.Common.UI.Unit">Gets or sets the width of the dropdown. Inherited from Picker.</field>
				/// <field name="invalidString" type="String">Gets or sets the string to display when the input is invalid. Inherited from Picker.</field>
				/// <field name="state" type="MindFusion.Common.UI.ValidationState">Gets or sets the validation state of the control. Inherited from Picker.</field>
				/// <field name="dropDownClose" type="EventDispatcher">Raised when the dropdown is closed. Syntax: dropDownClose.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
				/// <field name="dropDownShow" type="EventDispatcher">Raised when the dropdown is shown. Syntax: dropDownShow.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
				/// <field name="stateChanged" type="EventDispatcher">Raised when the control validation state is changed. Syntax: stateChanged.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
				/// <field name="valueChanged" type="EventDispatcher">Raised when the dropdown is closed. Syntax: valueChanged.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
				/// <field name="valueChanging" type="EventDispatcher">Raised when the control value is changing. Syntax: valueChanging.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
			},
			DateTimeView: function (element) {
				/// <summary>A base class for calendar views.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="date" type="Date">Gets the date of this view.</field>
				/// <field name="formatInfo" type="MindFusion.Common.UI.DateSettings">Gets the DateSettings object used to format and display date and time information in the view.</field>
				/// <field name="locale" type="MindFusion.Common.UI.Locale">Gets or sets the locale object used to format and display localizable information in the view.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} );</field>
				/// <field name="cellClick" type="EventDispatcher">Raised when a date-time cell is clicked. Syntax: cellClick.addEventListener( function(sender, args){} );</field>
			},
			DayView: function (element) {
				/// <summary>Displays a day, represented by a grid of arbitrary time interval cells.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="interval" type="Number">Gets or sets the time interval of a view cell in milliseconds.</field>
				/// <field name="maxTime" type="Number">Gets or sets the maxmimum value displayed in the view.</field>
				/// <field name="minTime" type="Number">Gets or sets the minimum value displayed in the view.</field>
				/// <field name="date" type="Date">Gets the date of this view. Inherited from DateTimeView.</field>
				/// <field name="formatInfo" type="MindFusion.Common.UI.DateSettings">Gets the DateSettings object used to format and display date and time information in the view. Inherited from DateTimeView.</field>
				/// <field name="locale" type="MindFusion.Common.UI.Locale">Gets or sets the locale object used to format and display localizable information in the view. Inherited from DateTimeView.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} ); Inherited from DateTimeView.</field>
				/// <field name="cellClick" type="EventDispatcher">Raised when a date-time cell is clicked. Syntax: cellClick.addEventListener( function(sender, args){} ); Inherited from DateTimeView.</field>
			},
			DecadeView: function (element) {
				/// <summary>Displays a decade, represented by a grid of year cells.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="date" type="Date">Gets the date of this view. Inherited from DateTimeView.</field>
				/// <field name="formatInfo" type="MindFusion.Common.UI.DateSettings">Gets the DateSettings object used to format and display date and time information in the view. Inherited from DateTimeView.</field>
				/// <field name="locale" type="MindFusion.Common.UI.Locale">Gets or sets the locale object used to format and display localizable information in the view. Inherited from DateTimeView.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} ); Inherited from DateTimeView.</field>
				/// <field name="cellClick" type="EventDispatcher">Raised when a date-time cell is clicked. Syntax: cellClick.addEventListener( function(sender, args){} ); Inherited from DateTimeView.</field>
			},
			Dialog: function (parent) {
				/// <summary>Represents a modal dialog box.</summary>
				/// <param name="parent" type="HTMLElement">HTMLElement. The DOM element to which to append the dialog.</param>
				/// <field name="host" type="MindFusion.Common.UI.Container">Gets the host of this WindowHost. Inherited from WindowBase.</field>
				/// <field name="navigateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded in the control's content IFrame. Inherited from WindowBase.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the content template. Inherited from WindowBase.</field>
				/// <field name="templateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded as a control content template. Inherited from WindowBase.</field>
				/// <field name="windowState" type="MindFusion.Common.UI.WindowState">Gets or sets the state of this Window. Inherited from WindowBase.</field>
				/// <field name="allowClose" type="Boolean">Gets or sets a value indicating whether this Window can be closed. Inherited from Window.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets a value indicating whether this Window can be dragged. Inherited from Window.</field>
				/// <field name="allowMaximize" type="Boolean">Gets or sets a value indicating whether this Window can be maximized. Inherited from Window.</field>
				/// <field name="allowMinimize" type="Boolean">Gets or sets a value indicating whether this Window can be minimized. Inherited from Window.</field>
				/// <field name="allowPin" type="Boolean">Gets or sets a value indicating whether this Window can be pinned. Inherited from Window.</field>
				/// <field name="allowRefresh" type="Boolean">Gets or sets a value indicating whether this Window can be refreshed. Inherited from Window.</field>
				/// <field name="allowResize" type="Boolean">Gets or sets a value indicating whether this Window can be resized. Inherited from Window.</field>
				/// <field name="footer" type="HTMLDivElement">Gets a reference to the Window footer DOM element. Inherited from Window.</field>
				/// <field name="header" type="HTMLDivElement">Gets a reference to the Window header DOM element. Inherited from Window.</field>
				/// <field name="iconSrc" type="String">Gets or sets the url of the title icon. Inherited from Window.</field>
				/// <field name="minHeight" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed height of this Window. Inherited from Window.</field>
				/// <field name="minWidth" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed width of this Window. Inherited from Window.</field>
				/// <field name="modal" type="Boolean">Gets or sets a value indicating whether this Window should be modal. Inherited from Window.</field>
				/// <field name="pinned" type="Boolean">Gets or sets a value, indicating whether this Window is pinned. Inherited from Window.</field>
				/// <field name="title" type="String">Gets or sets the title of this Window. Inherited from Window.</field>
				/// <field name="useFrameTitle" type="Boolean">Gets or sets a value indicating whether the window will display the title of its content iframe. Inherited from Window.</field>
				/// <field name="contentLoad" type="EventDispatcher">Raised when the windows's contents are loaded. Syntax: contentLoad.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanged" type="EventDispatcher">Raised when the window's state is changed. Syntax: stateChanged.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanging" type="EventDispatcher">Raised when the window's state is changing. Syntax: stateChanging.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClose" type="EventDispatcher">Raised when the Window is closed. Syntax: windowClose.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClosing" type="EventDispatcher">Raised when the Window is closing. Syntax: windowClosing.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpen" type="EventDispatcher">Raised when the Window is opened. Syntax: windowOpen.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpening" type="EventDispatcher">Raised when the Window is opening. Syntax: windowOpening.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip of the Window&#160;is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="dragEnd" type="EventDispatcher">Raised when drag operation is finished. Syntax: dragEnd.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="dragStart" type="EventDispatcher">Raised when a drag operation is started. Syntax: dragStart.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="headerClick" type="EventDispatcher">Raised when the Window header is clicked. Syntax: headerClick.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="resizeEnd" type="EventDispatcher">Raised when a resize operation is finished. Syntax: resizeEnd.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="resizeStart" type="EventDispatcher">Raised when a resize operation is started. Syntax: resizeStart.addEventListener( function(sender, args){} ); Inherited from Window.</field>
			},
			Dialogs: function () {
				/// <summary>Contains static methods for different user dialogs.</summary>
			},
			DragDropEventArgs: function (dragItem, dropTarget) {
				/// <summary>Specifies data for drag and drop related events.</summary>
				/// <param name="dragItem" type="ListItem">ListItem. The item, associated with the event.</param>
				/// <param name="dropTarget" type="Object">Object. An object, containing data about the target of the operation.</param>
				/// <field name="dragItem" type="MindFusion.Common.UI.ListItem">Gets the item, associated with the event.</field>
				/// <field name="dropTarget" type="Object">Gets an object, containing data about the target of the operation.</field>
			},
			DropDown: function (parent) {
				/// <summary>Represents a dropdown for a Picker control.</summary>
				/// <param name="parent" type="Picker">Picker. The parent Picker control.</param>
				/// <field name="follow" type="Boolean">Gets or sets a value indicating whether the ToolTip will follow the mouse cursor. Inherited from Tooltip.</field>
				/// <field name="offset" type="MindFusion.Common.UI.Point">Gets or sets the offset of the Tooltip. Inherited from Tooltip.</field>
				/// <field name="position" type="MindFusion.Common.UI.TooltipPosition">Gets or sets the position of the Tooltip. Inherited from Tooltip.</field>
				/// <field name="target" type="HTMLElement">Gets a reference to the tooltip's target element. Inherited from Tooltip.</field>
				/// <field name="template" type="String">Gets or sets the ToolTip content template. Inherited from Tooltip.</field>
				/// <field name="text" type="String">Gets or sets the text of the ToolTip. Inherited from Tooltip.</field>
				/// <field name="trigger" type="MindFusion.Common.UI.TooltipTrigger">Gets or sets the event, which shows the ToolTip. Inherited from Tooltip.</field>
				/// <field name="tooltipHide" type="EventDispatcher">Raised when the ToolTip is hidden. Syntax: tooltipHide.addEventListener( function(sender, args){} ); Inherited from Tooltip.</field>
				/// <field name="tooltipHiding" type="EventDispatcher">Raised when the ToolTip is hiding. Syntax: tooltipHiding.addEventListener( function(sender, args){} ); Inherited from Tooltip.</field>
				/// <field name="tooltipShow" type="EventDispatcher">Raised when the Tooltip is shown. Syntax: tooltipShow.addEventListener( function(sender, args){} ); Inherited from Tooltip.</field>
				/// <field name="tooltipShowing" type="EventDispatcher">Raised when the Tooltip is showing. Syntax: tooltipShowing.addEventListener( function(sender, args){} ); Inherited from Tooltip.</field>
			},
			ImagePicker: function (element) {
				/// <summary>Represents an input control with the ability to select images from the filesystem or a predefined list.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="imageIndex" type="Number">Gets or sets the index of the selected image.</field>
				/// <field name="itemSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the dropdown items.</field>
				/// <field name="imageList" type="Array">Gets or sets the list of images to choose from.</field>
				/// <field name="allowEmptyInput" type="Boolean">Gets or sets a value indicating whether empty input is considered valid. Inherited from Picker.</field>
				/// <field name="buttonStyle" type="MindFusion.Common.UI.PickerButtonStyle">Gets or sets a value indicating the display mode of the dropdown button. Inherited from Picker.</field>
				/// <field name="clearButtonStyle" type="MindFusion.Common.UI.PickerButtonStyle">Gets or sets a value indicating the display mode of the clear button. Inherited from Picker.</field>
				/// <field name="createWrapper" type="Boolean">Gets or sets a value indicating whether a wrapper div element should be created for the control. Inherited from Picker.</field>
				/// <field name="dropdownHeight" type="MindFusion.Common.UI.Unit">Gets or sets the height of the dropdown. Inherited from Picker.</field>
				/// <field name="dropdownOffset" type="MindFusion.Common.UI.Point">Gets or sets the offset of the dropdown. Inherited from Picker.</field>
				/// <field name="dropdownWidth" type="MindFusion.Common.UI.Unit">Gets or sets the width of the dropdown. Inherited from Picker.</field>
				/// <field name="invalidString" type="String">Gets or sets the string to display when the input is invalid. Inherited from Picker.</field>
				/// <field name="state" type="MindFusion.Common.UI.ValidationState">Gets or sets the validation state of the control. Inherited from Picker.</field>
				/// <field name="dropDownClose" type="EventDispatcher">Raised when the dropdown is closed. Syntax: dropDownClose.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
				/// <field name="dropDownShow" type="EventDispatcher">Raised when the dropdown is shown. Syntax: dropDownShow.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
				/// <field name="stateChanged" type="EventDispatcher">Raised when the control validation state is changed. Syntax: stateChanged.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
				/// <field name="valueChanged" type="EventDispatcher">Raised when the dropdown is closed. Syntax: valueChanged.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
				/// <field name="valueChanging" type="EventDispatcher">Raised when the control value is changing. Syntax: valueChanging.addEventListener( function(sender, args){} ); Inherited from Picker.</field>
			},
			InfoDialog: function (title, message, parent) {
				/// <summary>Represents a modal dialog box, displaying a custom message.</summary>
				/// <param name="title" type="String" optional="true">Optional. String. The text to display as a dialog title.</param>
				/// <param name="message" type="String" optional="true">Optional. String. The message to display as the dialog text.</param>
				/// <param name="parent" type="HTMLElement" optional="true">Optional. HTMLElement. The Dom element to append the dialog to.If the parameter is not specified, the dialog will be appended to document.body.</param>
				/// <field name="host" type="MindFusion.Common.UI.Container">Gets the host of this WindowHost. Inherited from WindowBase.</field>
				/// <field name="navigateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded in the control's content IFrame. Inherited from WindowBase.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the content template. Inherited from WindowBase.</field>
				/// <field name="templateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded as a control content template. Inherited from WindowBase.</field>
				/// <field name="windowState" type="MindFusion.Common.UI.WindowState">Gets or sets the state of this Window. Inherited from WindowBase.</field>
				/// <field name="allowClose" type="Boolean">Gets or sets a value indicating whether this Window can be closed. Inherited from Window.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets a value indicating whether this Window can be dragged. Inherited from Window.</field>
				/// <field name="allowMaximize" type="Boolean">Gets or sets a value indicating whether this Window can be maximized. Inherited from Window.</field>
				/// <field name="allowMinimize" type="Boolean">Gets or sets a value indicating whether this Window can be minimized. Inherited from Window.</field>
				/// <field name="allowPin" type="Boolean">Gets or sets a value indicating whether this Window can be pinned. Inherited from Window.</field>
				/// <field name="allowRefresh" type="Boolean">Gets or sets a value indicating whether this Window can be refreshed. Inherited from Window.</field>
				/// <field name="allowResize" type="Boolean">Gets or sets a value indicating whether this Window can be resized. Inherited from Window.</field>
				/// <field name="footer" type="HTMLDivElement">Gets a reference to the Window footer DOM element. Inherited from Window.</field>
				/// <field name="header" type="HTMLDivElement">Gets a reference to the Window header DOM element. Inherited from Window.</field>
				/// <field name="iconSrc" type="String">Gets or sets the url of the title icon. Inherited from Window.</field>
				/// <field name="minHeight" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed height of this Window. Inherited from Window.</field>
				/// <field name="minWidth" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed width of this Window. Inherited from Window.</field>
				/// <field name="modal" type="Boolean">Gets or sets a value indicating whether this Window should be modal. Inherited from Window.</field>
				/// <field name="pinned" type="Boolean">Gets or sets a value, indicating whether this Window is pinned. Inherited from Window.</field>
				/// <field name="title" type="String">Gets or sets the title of this Window. Inherited from Window.</field>
				/// <field name="useFrameTitle" type="Boolean">Gets or sets a value indicating whether the window will display the title of its content iframe. Inherited from Window.</field>
				/// <field name="contentLoad" type="EventDispatcher">Raised when the windows's contents are loaded. Syntax: contentLoad.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanged" type="EventDispatcher">Raised when the window's state is changed. Syntax: stateChanged.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanging" type="EventDispatcher">Raised when the window's state is changing. Syntax: stateChanging.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClose" type="EventDispatcher">Raised when the Window is closed. Syntax: windowClose.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClosing" type="EventDispatcher">Raised when the Window is closing. Syntax: windowClosing.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpen" type="EventDispatcher">Raised when the Window is opened. Syntax: windowOpen.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpening" type="EventDispatcher">Raised when the Window is opening. Syntax: windowOpening.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip of the Window&#160;is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="dragEnd" type="EventDispatcher">Raised when drag operation is finished. Syntax: dragEnd.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="dragStart" type="EventDispatcher">Raised when a drag operation is started. Syntax: dragStart.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="headerClick" type="EventDispatcher">Raised when the Window header is clicked. Syntax: headerClick.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="resizeEnd" type="EventDispatcher">Raised when a resize operation is finished. Syntax: resizeEnd.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="resizeStart" type="EventDispatcher">Raised when a resize operation is started. Syntax: resizeStart.addEventListener( function(sender, args){} ); Inherited from Window.</field>
			},
			InputDialog: function (title, message, parent, input, property) {
				/// <summary>Represents a modal Dialog box, displaying a custom input control.</summary>
				/// <param name="title" type="String" optional="true">Optional. String. The text to display as a dialog title.</param>
				/// <param name="message" type="String" optional="true">Optional. String. The message to display as the dialog text.</param>
				/// <param name="parent" type="HTMLElement" optional="true">Optional. HTMLElement. The Dom element to append the dialog to.If the parameter is not specified, the dialog will be appended to document.body.</param>
				/// <param name="input" type="HTMLElement" optional="true">Optional. HTMLElement. The input control to show in the dialog. If the parameter is not specified, an empty HTML text input will be displayed.</param>
				/// <param name="property" type="String" optional="true">Optional. String. The name of the property of the input control, whose value will be passed as the second argument to the callback function.If the parameter is not specified, the value property will be used.</param>
				/// <field name="input" type="HTMLElement">Gets a reference to the dialog's input element.</field>
				/// <field name="host" type="MindFusion.Common.UI.Container">Gets the host of this WindowHost. Inherited from WindowBase.</field>
				/// <field name="navigateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded in the control's content IFrame. Inherited from WindowBase.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the content template. Inherited from WindowBase.</field>
				/// <field name="templateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded as a control content template. Inherited from WindowBase.</field>
				/// <field name="windowState" type="MindFusion.Common.UI.WindowState">Gets or sets the state of this Window. Inherited from WindowBase.</field>
				/// <field name="allowClose" type="Boolean">Gets or sets a value indicating whether this Window can be closed. Inherited from Window.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets a value indicating whether this Window can be dragged. Inherited from Window.</field>
				/// <field name="allowMaximize" type="Boolean">Gets or sets a value indicating whether this Window can be maximized. Inherited from Window.</field>
				/// <field name="allowMinimize" type="Boolean">Gets or sets a value indicating whether this Window can be minimized. Inherited from Window.</field>
				/// <field name="allowPin" type="Boolean">Gets or sets a value indicating whether this Window can be pinned. Inherited from Window.</field>
				/// <field name="allowRefresh" type="Boolean">Gets or sets a value indicating whether this Window can be refreshed. Inherited from Window.</field>
				/// <field name="allowResize" type="Boolean">Gets or sets a value indicating whether this Window can be resized. Inherited from Window.</field>
				/// <field name="footer" type="HTMLDivElement">Gets a reference to the Window footer DOM element. Inherited from Window.</field>
				/// <field name="header" type="HTMLDivElement">Gets a reference to the Window header DOM element. Inherited from Window.</field>
				/// <field name="iconSrc" type="String">Gets or sets the url of the title icon. Inherited from Window.</field>
				/// <field name="minHeight" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed height of this Window. Inherited from Window.</field>
				/// <field name="minWidth" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed width of this Window. Inherited from Window.</field>
				/// <field name="modal" type="Boolean">Gets or sets a value indicating whether this Window should be modal. Inherited from Window.</field>
				/// <field name="pinned" type="Boolean">Gets or sets a value, indicating whether this Window is pinned. Inherited from Window.</field>
				/// <field name="title" type="String">Gets or sets the title of this Window. Inherited from Window.</field>
				/// <field name="useFrameTitle" type="Boolean">Gets or sets a value indicating whether the window will display the title of its content iframe. Inherited from Window.</field>
				/// <field name="contentLoad" type="EventDispatcher">Raised when the windows's contents are loaded. Syntax: contentLoad.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanged" type="EventDispatcher">Raised when the window's state is changed. Syntax: stateChanged.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanging" type="EventDispatcher">Raised when the window's state is changing. Syntax: stateChanging.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClose" type="EventDispatcher">Raised when the Window is closed. Syntax: windowClose.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClosing" type="EventDispatcher">Raised when the Window is closing. Syntax: windowClosing.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpen" type="EventDispatcher">Raised when the Window is opened. Syntax: windowOpen.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpening" type="EventDispatcher">Raised when the Window is opening. Syntax: windowOpening.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip of the Window&#160;is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="dragEnd" type="EventDispatcher">Raised when drag operation is finished. Syntax: dragEnd.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="dragStart" type="EventDispatcher">Raised when a drag operation is started. Syntax: dragStart.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="headerClick" type="EventDispatcher">Raised when the Window header is clicked. Syntax: headerClick.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="resizeEnd" type="EventDispatcher">Raised when a resize operation is finished. Syntax: resizeEnd.addEventListener( function(sender, args){} ); Inherited from Window.</field>
				/// <field name="resizeStart" type="EventDispatcher">Raised when a resize operation is started. Syntax: resizeStart.addEventListener( function(sender, args){} ); Inherited from Window.</field>
			},
			InteractionEventArgs: function (rawEventArgs, action) {
				/// <summary>Contains the arguments passed to handlers of interaction-related events.</summary>
				/// <param name="rawEventArgs" type="Object">Object. The Javascript event data.</param>
				/// <param name="action" type="InteractionType">InteractionType. The action associated with the event.</param>
				/// <field name="action" type="MindFusion.Common.UI.InteractionType">Gets the action associated with the event.</field>
				/// <field name="rawEventArgs" type="Object">Gets the Javascript event data.</field>
			},
			ItemEventArgs: function (item, rawEventArgs) {
				/// <summary>Specifies data for the item related events.</summary>
				/// <param name="item" type="ListItem">ListItem. The item, associated with the event.</param>
				/// <param name="rawEventArgs" type="Object">Object. The Javascript event data.</param>
				/// <field name="item" type="MindFusion.Common.UI.ListItem">Gets the item, associated with the event.</field>
				/// <field name="rawEventArgs" type="Object">Gets the JavaScript event data.</field>
			},
			ListContainer: function (element) {
				/// <summary>A base class for UI controls, which serve as a container for a list of items.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="acceptDrop" type="MindFusion.Common.UI.ListItem">Gets or sets the ListItem instance that can be dropped.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets whether drag and drop capabilities are enabled.</field>
				/// <field name="allowDrop" type="Boolean">Gets or sets whether the ListContainer control can be used as a drop target.</field>
				/// <field name="allowMultipleSelection" type="Boolean">Gets or sets whether users are allowed to select more than one item at a time.</field>
				/// <field name="content" type="HTMLElement">Gets a reference to the container's content element.</field>
				/// <field name="items" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of ListItem-s.</field>
				/// <field name="itemSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the list items.</field>
				/// <field name="orientation" type="MindFusion.Common.UI.Orientation">Gets or sets a value indicating how list items are arranged.</field>
				/// <field name="selection" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of selected items.</field>
				/// <field name="dragDrop" type="EventDispatcher">Raised when an item is dropped onto the control. Syntax: dragDrop.addEventListener( function(sender, args){} );</field>
				/// <field name="dragOver" type="EventDispatcher">Raised when an item is dragged over the control. Syntax: dragOver.addEventListener( function(sender, args){} );</field>
				/// <field name="itemClick" type="EventDispatcher">Raised when an item is clicked. Syntax: itemClick.addEventListener( function(sender, args){} );</field>
				/// <field name="itemDoubleClick" type="EventDispatcher">Raised when an item is double-clicked. Syntax: itemDoubleClick.addEventListener( function(sender, args){} );</field>
				/// <field name="itemDrag" type="EventDispatcher">Raised when an item is dragged. Syntax: itemDrag.addEventListener( function(sender, args){} );</field>
				/// <field name="itemDragEnd" type="EventDispatcher">Raised when a drag operation on an item is finished. Syntax: itemDragEnd.addEventListener( function(sender, args){} );</field>
				/// <field name="itemDragStart" type="EventDispatcher">Raised when a drag operation on an item is started. Syntax: itemDragStart.addEventListener( function(sender, args){} );</field>
				/// <field name="itemDraw" type="EventDispatcher">Raised when an item is being drawn. Syntax: itemDraw.addEventListener( function(sender, args){} );</field>
				/// <field name="itemDrop" type="EventDispatcher">Raised when a drop operation is finished. Syntax: itemDrop.addEventListener( function(sender, args){} );</field>
				/// <field name="itemMouseDown" type="EventDispatcher">Raised when a mousedown event occurs in an item's element. Syntax: itemMouseDown.addEventListener( function(sender, args){} );</field>
				/// <field name="itemMouseEnter" type="EventDispatcher">Raised when a mouseenter event occurs in an item's element. Syntax: itemMouseEnter.addEventListener( function(sender, args){} );</field>
				/// <field name="itemMouseLeave" type="EventDispatcher">Raised when a mouseleave event occurs in an item's element. Syntax: itemMouseLeave.addEventListener( function(sender, args){} );</field>
				/// <field name="itemsChanged" type="EventDispatcher">Raised when the items collection is changed. Syntax: itemsChanged.addEventListener( function(sender, args){} );</field>
				/// <field name="itemsChanging" type="EventDispatcher">Raised when the items collection is changing. Syntax: itemsChanging.addEventListener( function(sender, args){} );</field>
				/// <field name="selectionChanged" type="EventDispatcher">Raised when the selection collection is changed. Syntax: selectionChanged.addEventListener( function(sender, args){} );</field>
				/// <field name="selectionChanging" type="EventDispatcher">Raised when the selection collection is changing. Syntax: selectionChanging.addEventListener( function(sender, args){} );</field>
			},
			ListItem: function (title) {
				/// <summary>Represents an item in a ListContainer control.</summary>
				/// <param name="title" type="String" optional="true">Optional. String. The display text of this item.</param>
				/// <field name="bounds" type="MindFusion.Common.UI.Rect">Gets the bounds of this ListItem.</field>
				/// <field name="contentElement" type="HTMLElement">Gets a reference to the item's content element.</field>
				/// <field name="cssClass" type="String">Gets or sets the css class of this ListItem.</field>
				/// <field name="data" type="Object">Gets or sets an object, holding custom user data.</field>
				/// <field name="dataIndex" type="Number">Gets or sets the unique index of this item.</field>
				/// <field name="element" type="HTMLElement">Gets a reference to the item's DOM element.</field>
				/// <field name="enabled" type="Boolean">Gets or sets a value indicating whether user interactions are allowed for this item.</field>
				/// <field name="imageSrc" type="String">Gets or sets the URL of the image displayed by this item.</field>
				/// <field name="interactive" type="Boolean">Gets or sets a value indicating whether drag and drop operations are allowed for this ListItem.</field>
				/// <field name="loaded" type="Boolean">Gets a value indicating whether this item is loaded and ready for interaction.</field>
				/// <field name="selected" type="Boolean">Gets a value indicating whether the item is selected.</field>
				/// <field name="size" type="MindFusion.Common.UI.Unit">Gets or sets the size of this item.</field>
				/// <field name="title" type="String">Gets or sets the display text of this item.</field>
				/// <field name="tooltip" type="String">Gets or sets the tooltip of this ListItem.</field>
				/// <field name="visible" type="Boolean">Gets or sets the visibility of this ListItem.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the template. Inherited from TemplatedItem.</field>
			},
			ListView: function (element) {
				/// <summary>Represents a list view control.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="acceptDrop" type="MindFusion.Common.UI.ListItem">Gets or sets the ListItem instance that can be dropped. Inherited from ListContainer.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets whether drag and drop capabilities are enabled. Inherited from ListContainer.</field>
				/// <field name="allowDrop" type="Boolean">Gets or sets whether the ListContainer control can be used as a drop target. Inherited from ListContainer.</field>
				/// <field name="allowMultipleSelection" type="Boolean">Gets or sets whether users are allowed to select more than one item at a time. Inherited from ListContainer.</field>
				/// <field name="content" type="HTMLElement">Gets a reference to the container's content element. Inherited from ListContainer.</field>
				/// <field name="items" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of ListItem-s. Inherited from ListContainer.</field>
				/// <field name="itemSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the list items. Inherited from ListContainer.</field>
				/// <field name="orientation" type="MindFusion.Common.UI.Orientation">Gets or sets a value indicating how list items are arranged. Inherited from ListContainer.</field>
				/// <field name="selection" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of selected items. Inherited from ListContainer.</field>
				/// <field name="dragDrop" type="EventDispatcher">Raised when an item is dropped onto the control. Syntax: dragDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="dragOver" type="EventDispatcher">Raised when an item is dragged over the control. Syntax: dragOver.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemClick" type="EventDispatcher">Raised when an item is clicked. Syntax: itemClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDoubleClick" type="EventDispatcher">Raised when an item is double-clicked. Syntax: itemDoubleClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrag" type="EventDispatcher">Raised when an item is dragged. Syntax: itemDrag.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragEnd" type="EventDispatcher">Raised when a drag operation on an item is finished. Syntax: itemDragEnd.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragStart" type="EventDispatcher">Raised when a drag operation on an item is started. Syntax: itemDragStart.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDraw" type="EventDispatcher">Raised when an item is being drawn. Syntax: itemDraw.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrop" type="EventDispatcher">Raised when a drop operation is finished. Syntax: itemDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseDown" type="EventDispatcher">Raised when a mousedown event occurs in an item's element. Syntax: itemMouseDown.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseEnter" type="EventDispatcher">Raised when a mouseenter event occurs in an item's element. Syntax: itemMouseEnter.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseLeave" type="EventDispatcher">Raised when a mouseleave event occurs in an item's element. Syntax: itemMouseLeave.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanged" type="EventDispatcher">Raised when the items collection is changed. Syntax: itemsChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanging" type="EventDispatcher">Raised when the items collection is changing. Syntax: itemsChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanged" type="EventDispatcher">Raised when the selection collection is changed. Syntax: selectionChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanging" type="EventDispatcher">Raised when the selection collection is changing. Syntax: selectionChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
			},
			Menu: function (element) {
				/// <summary>Represents a vertical menu.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="closeTimeout" type="Number">Gets or sets the number of milliseconds to wait before closing an item.</field>
				/// <field name="flatItems" type="MindFusion.Common.UI.List">Gets the collection of items as a flat list.</field>
				/// <field name="loadedItems" type="MindFusion.Common.UI.List">Gets the collection of loaded items as a flat list.</field>
				/// <field name="loadOnDemand" type="Boolean">Gets or sets a value indicating whether menu items DOM will be created only after their parent item is expanded.</field>
				/// <field name="acceptDrop" type="MindFusion.Common.UI.ListItem">Gets or sets the ListItem instance that can be dropped. Inherited from ListContainer.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets whether drag and drop capabilities are enabled. Inherited from ListContainer.</field>
				/// <field name="allowDrop" type="Boolean">Gets or sets whether the ListContainer control can be used as a drop target. Inherited from ListContainer.</field>
				/// <field name="allowMultipleSelection" type="Boolean">Gets or sets whether users are allowed to select more than one item at a time. Inherited from ListContainer.</field>
				/// <field name="content" type="HTMLElement">Gets a reference to the container's content element. Inherited from ListContainer.</field>
				/// <field name="items" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of ListItem-s. Inherited from ListContainer.</field>
				/// <field name="itemSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the list items. Inherited from ListContainer.</field>
				/// <field name="orientation" type="MindFusion.Common.UI.Orientation">Gets or sets a value indicating how list items are arranged. Inherited from ListContainer.</field>
				/// <field name="selection" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of selected items. Inherited from ListContainer.</field>
				/// <field name="dragDrop" type="EventDispatcher">Raised when an item is dropped onto the control. Syntax: dragDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="dragOver" type="EventDispatcher">Raised when an item is dragged over the control. Syntax: dragOver.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemClick" type="EventDispatcher">Raised when an item is clicked. Syntax: itemClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDoubleClick" type="EventDispatcher">Raised when an item is double-clicked. Syntax: itemDoubleClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrag" type="EventDispatcher">Raised when an item is dragged. Syntax: itemDrag.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragEnd" type="EventDispatcher">Raised when a drag operation on an item is finished. Syntax: itemDragEnd.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragStart" type="EventDispatcher">Raised when a drag operation on an item is started. Syntax: itemDragStart.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDraw" type="EventDispatcher">Raised when an item is being drawn. Syntax: itemDraw.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrop" type="EventDispatcher">Raised when a drop operation is finished. Syntax: itemDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseDown" type="EventDispatcher">Raised when a mousedown event occurs in an item's element. Syntax: itemMouseDown.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseEnter" type="EventDispatcher">Raised when a mouseenter event occurs in an item's element. Syntax: itemMouseEnter.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseLeave" type="EventDispatcher">Raised when a mouseleave event occurs in an item's element. Syntax: itemMouseLeave.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanged" type="EventDispatcher">Raised when the items collection is changed. Syntax: itemsChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanging" type="EventDispatcher">Raised when the items collection is changing. Syntax: itemsChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanged" type="EventDispatcher">Raised when the selection collection is changed. Syntax: selectionChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanging" type="EventDispatcher">Raised when the selection collection is changing. Syntax: selectionChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
			},
			MenuItem: function (title, href) {
				/// <summary>Represents an item in a menu.</summary>
				/// <param name="title" type="String" optional="true">Optional. String. The display text of this item.</param>
				/// <param name="href" type="String" optional="true">Optional. String. The URL this item is pointing to.</param>
				/// <field name="href" type="String">Gets or sets the URL this item is pointing to.</field>
				/// <field name="target" type="String">Gets or sets a value indicating where the linked document is loaded.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the template. Inherited from TemplatedItem.</field>
				/// <field name="bounds" type="MindFusion.Common.UI.Rect">Gets the bounds of this ListItem. Inherited from ListItem.</field>
				/// <field name="contentElement" type="HTMLElement">Gets a reference to the item's content element. Inherited from ListItem.</field>
				/// <field name="cssClass" type="String">Gets or sets the css class of this ListItem. Inherited from ListItem.</field>
				/// <field name="data" type="Object">Gets or sets an object, holding custom user data. Inherited from ListItem.</field>
				/// <field name="dataIndex" type="Number">Gets or sets the unique index of this item. Inherited from ListItem.</field>
				/// <field name="element" type="HTMLElement">Gets a reference to the item's DOM element. Inherited from ListItem.</field>
				/// <field name="enabled" type="Boolean">Gets or sets a value indicating whether user interactions are allowed for this item. Inherited from ListItem.</field>
				/// <field name="imageSrc" type="String">Gets or sets the URL of the image displayed by this item. Inherited from ListItem.</field>
				/// <field name="interactive" type="Boolean">Gets or sets a value indicating whether drag and drop operations are allowed for this ListItem. Inherited from ListItem.</field>
				/// <field name="loaded" type="Boolean">Gets a value indicating whether this item is loaded and ready for interaction. Inherited from ListItem.</field>
				/// <field name="selected" type="Boolean">Gets a value indicating whether the item is selected. Inherited from ListItem.</field>
				/// <field name="size" type="MindFusion.Common.UI.Unit">Gets or sets the size of this item. Inherited from ListItem.</field>
				/// <field name="title" type="String">Gets or sets the display text of this item. Inherited from ListItem.</field>
				/// <field name="tooltip" type="String">Gets or sets the tooltip of this ListItem. Inherited from ListItem.</field>
				/// <field name="visible" type="Boolean">Gets or sets the visibility of this ListItem. Inherited from ListItem.</field>
				/// <field name="expandable" type="Boolean">Gets a value indicating whether the TreeNode is expandable. Inherited from TreeNode.</field>
				/// <field name="expanded" type="Boolean">Gets or sets a value indicating whether the TreeNode is expanded. Inherited from TreeNode.</field>
				/// <field name="flatItems" type="MindFusion.Common.UI.List">Gets the collection of children items as a flat list. Inherited from TreeNode.</field>
				/// <field name="items" type="MindFusion.Common.UI.ObservableCollection">Gets the children of the TreeNode. Inherited from TreeNode.</field>
				/// <field name="level" type="Number">Gets the depth of the TreeNode in the TreeView hierarchy. Inherited from TreeNode.</field>
			},
			MonthView: function (element) {
				/// <summary>Displays a month, represented by a grid of day cells.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="date" type="Date">Gets the date of this view. Inherited from DateTimeView.</field>
				/// <field name="formatInfo" type="MindFusion.Common.UI.DateSettings">Gets the DateSettings object used to format and display date and time information in the view. Inherited from DateTimeView.</field>
				/// <field name="locale" type="MindFusion.Common.UI.Locale">Gets or sets the locale object used to format and display localizable information in the view. Inherited from DateTimeView.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} ); Inherited from DateTimeView.</field>
				/// <field name="cellClick" type="EventDispatcher">Raised when a date-time cell is clicked. Syntax: cellClick.addEventListener( function(sender, args){} ); Inherited from DateTimeView.</field>
			},
			Picker: function (element) {
				/// <summary>A base class for picker controls.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="allowEmptyInput" type="Boolean">Gets or sets a value indicating whether empty input is considered valid.</field>
				/// <field name="buttonStyle" type="MindFusion.Common.UI.PickerButtonStyle">Gets or sets a value indicating the display mode of the dropdown button.</field>
				/// <field name="clearButtonStyle" type="MindFusion.Common.UI.PickerButtonStyle">Gets or sets a value indicating the display mode of the clear button.</field>
				/// <field name="createWrapper" type="Boolean">Gets or sets a value indicating whether a wrapper div element should be created for the control.</field>
				/// <field name="dropdownHeight" type="MindFusion.Common.UI.Unit">Gets or sets the height of the dropdown.</field>
				/// <field name="dropdownOffset" type="MindFusion.Common.UI.Point">Gets or sets the offset of the dropdown.</field>
				/// <field name="dropdownWidth" type="MindFusion.Common.UI.Unit">Gets or sets the width of the dropdown.</field>
				/// <field name="invalidString" type="String">Gets or sets the string to display when the input is invalid.</field>
				/// <field name="state" type="MindFusion.Common.UI.ValidationState">Gets or sets the validation state of the control.</field>
				/// <field name="dropDownClose" type="EventDispatcher">Raised when the dropdown is closed. Syntax: dropDownClose.addEventListener( function(sender, args){} );</field>
				/// <field name="dropDownShow" type="EventDispatcher">Raised when the dropdown is shown. Syntax: dropDownShow.addEventListener( function(sender, args){} );</field>
				/// <field name="stateChanged" type="EventDispatcher">Raised when the control validation state is changed. Syntax: stateChanged.addEventListener( function(sender, args){} );</field>
				/// <field name="valueChanged" type="EventDispatcher">Raised when the dropdown is closed. Syntax: valueChanged.addEventListener( function(sender, args){} );</field>
				/// <field name="valueChanging" type="EventDispatcher">Raised when the control value is changing. Syntax: valueChanging.addEventListener( function(sender, args){} );</field>
			},
			SelectedItemChangedEventArgs: function (oldItem, newItem) {
				/// <summary>Specifies data for selectedItemChanged events.</summary>
				/// <param name="oldItem" type="ListItem">ListItem. Gets the selected item before the change.</param>
				/// <param name="newItem" type="ListItem">ListItem. Gets the new selected item.</param>
				/// <field name="newItem" type="MindFusion.Common.UI.ListItem">Gets the new selected item.</field>
				/// <field name="oldItem" type="MindFusion.Common.UI.ListItem">Gets the selected item before the change.</field>
			},
			SelectedItemChangingEventArgs: function (oldItem, newItem) {
				/// <summary>Specifies data for selectedItemChanging events.</summary>
				/// <param name="oldItem" type="ListItem">ListItem. The selected item before the change.</param>
				/// <param name="newItem" type="ListItem">ListItem. The new selected item.</param>
				/// <field name="newItem" type="MindFusion.Common.UI.ListItem">Gets the new selected item.</field>
				/// <field name="oldItem" type="MindFusion.Common.UI.ListItem">Gets the selected item before the change.</field>
			},
			TabControl: function (element) {
				/// <summary>Represents a tab pages container.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="selectedIndex" type="Number">Gets the index of the currently selected tab page.</field>
				/// <field name="selectedItem" type="MindFusion.Common.UI.TabPage">Gets or sets the currently selected tab page.</field>
				/// <field name="tabs" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of tab pages.</field>
				/// <field name="tabSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the tab headers.</field>
				/// <field name="tabStripSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the TabStrip.</field>
				/// <field name="acceptDrop" type="MindFusion.Common.UI.ListItem">Gets or sets the ListItem instance that can be dropped. Inherited from ListContainer.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets whether drag and drop capabilities are enabled. Inherited from ListContainer.</field>
				/// <field name="allowDrop" type="Boolean">Gets or sets whether the ListContainer control can be used as a drop target. Inherited from ListContainer.</field>
				/// <field name="allowMultipleSelection" type="Boolean">Gets or sets whether users are allowed to select more than one item at a time. Inherited from ListContainer.</field>
				/// <field name="content" type="HTMLElement">Gets a reference to the container's content element. Inherited from ListContainer.</field>
				/// <field name="items" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of ListItem-s. Inherited from ListContainer.</field>
				/// <field name="itemSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the list items. Inherited from ListContainer.</field>
				/// <field name="orientation" type="MindFusion.Common.UI.Orientation">Gets or sets a value indicating how list items are arranged. Inherited from ListContainer.</field>
				/// <field name="selection" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of selected items. Inherited from ListContainer.</field>
				/// <field name="selectedItemChanged" type="EventDispatcher">Raised when the selected tab is changed. Syntax: selectedItemChanged.addEventListener( function(sender, args){} );</field>
				/// <field name="selectedItemChanging" type="EventDispatcher">Raised when the selected tab is changed. Syntax: selectedItemChanging.addEventListener( function(sender, args){} );</field>
				/// <field name="tabHeaderClick" type="EventDispatcher">Raised when a tab header is clicked. Syntax: tabHeaderClick.addEventListener( function(sender, args){} );</field>
				/// <field name="tabHeaderDraw" type="EventDispatcher">Raised when a tab header is drawn. Syntax: tabHeaderDraw.addEventListener( function(sender, args){} );</field>
				/// <field name="dragDrop" type="EventDispatcher">Raised when an item is dropped onto the control. Syntax: dragDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="dragOver" type="EventDispatcher">Raised when an item is dragged over the control. Syntax: dragOver.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemClick" type="EventDispatcher">Raised when an item is clicked. Syntax: itemClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDoubleClick" type="EventDispatcher">Raised when an item is double-clicked. Syntax: itemDoubleClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrag" type="EventDispatcher">Raised when an item is dragged. Syntax: itemDrag.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragEnd" type="EventDispatcher">Raised when a drag operation on an item is finished. Syntax: itemDragEnd.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragStart" type="EventDispatcher">Raised when a drag operation on an item is started. Syntax: itemDragStart.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDraw" type="EventDispatcher">Raised when an item is being drawn. Syntax: itemDraw.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrop" type="EventDispatcher">Raised when a drop operation is finished. Syntax: itemDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseDown" type="EventDispatcher">Raised when a mousedown event occurs in an item's element. Syntax: itemMouseDown.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseEnter" type="EventDispatcher">Raised when a mouseenter event occurs in an item's element. Syntax: itemMouseEnter.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseLeave" type="EventDispatcher">Raised when a mouseleave event occurs in an item's element. Syntax: itemMouseLeave.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanged" type="EventDispatcher">Raised when the items collection is changed. Syntax: itemsChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanging" type="EventDispatcher">Raised when the items collection is changing. Syntax: itemsChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanged" type="EventDispatcher">Raised when the selection collection is changed. Syntax: selectionChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanging" type="EventDispatcher">Raised when the selection collection is changing. Syntax: selectionChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
			},
			TabPage: function (title) {
				/// <summary>Represents a tab page in a TabControl.</summary>
				/// <param name="title" type="String" optional="true">Optional. String. The display text of this tab.</param>
				/// <field name="allowClose" type="Boolean">Gets or sets a value indicating whether to show a close button in the header of this tab page.</field>
				/// <field name="header" type="MindFusion.Common.UI.ToolStripItem">Gets a reference to the tab page header.</field>
				/// <field name="navigateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded in the content IFrame.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the content template.</field>
				/// <field name="templateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded as a content template.</field>
				/// <field name="bounds" type="MindFusion.Common.UI.Rect">Gets the bounds of this ListItem. Inherited from ListItem.</field>
				/// <field name="contentElement" type="HTMLElement">Gets a reference to the item's content element. Inherited from ListItem.</field>
				/// <field name="cssClass" type="String">Gets or sets the css class of this ListItem. Inherited from ListItem.</field>
				/// <field name="data" type="Object">Gets or sets an object, holding custom user data. Inherited from ListItem.</field>
				/// <field name="dataIndex" type="Number">Gets or sets the unique index of this item. Inherited from ListItem.</field>
				/// <field name="element" type="HTMLElement">Gets a reference to the item's DOM element. Inherited from ListItem.</field>
				/// <field name="enabled" type="Boolean">Gets or sets a value indicating whether user interactions are allowed for this item. Inherited from ListItem.</field>
				/// <field name="imageSrc" type="String">Gets or sets the URL of the image displayed by this item. Inherited from ListItem.</field>
				/// <field name="interactive" type="Boolean">Gets or sets a value indicating whether drag and drop operations are allowed for this ListItem. Inherited from ListItem.</field>
				/// <field name="loaded" type="Boolean">Gets a value indicating whether this item is loaded and ready for interaction. Inherited from ListItem.</field>
				/// <field name="selected" type="Boolean">Gets a value indicating whether the item is selected. Inherited from ListItem.</field>
				/// <field name="size" type="MindFusion.Common.UI.Unit">Gets or sets the size of this item. Inherited from ListItem.</field>
				/// <field name="title" type="String">Gets or sets the display text of this item. Inherited from ListItem.</field>
				/// <field name="tooltip" type="String">Gets or sets the tooltip of this ListItem. Inherited from ListItem.</field>
				/// <field name="visible" type="Boolean">Gets or sets the visibility of this ListItem. Inherited from ListItem.</field>
				/// <field name="contentLoad" type="EventDispatcher">Raised when the page's content is loaded. Syntax: contentLoad.addEventListener( function(sender, args){} );</field>
			},
			TabStrip: function (element) {
				/// <summary>Provides a container for tab headers.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="acceptDrop" type="MindFusion.Common.UI.ListItem">Gets or sets the ListItem instance that can be dropped. Inherited from ListContainer.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets whether drag and drop capabilities are enabled. Inherited from ListContainer.</field>
				/// <field name="allowDrop" type="Boolean">Gets or sets whether the ListContainer control can be used as a drop target. Inherited from ListContainer.</field>
				/// <field name="allowMultipleSelection" type="Boolean">Gets or sets whether users are allowed to select more than one item at a time. Inherited from ListContainer.</field>
				/// <field name="content" type="HTMLElement">Gets a reference to the container's content element. Inherited from ListContainer.</field>
				/// <field name="items" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of ListItem-s. Inherited from ListContainer.</field>
				/// <field name="itemSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the list items. Inherited from ListContainer.</field>
				/// <field name="orientation" type="MindFusion.Common.UI.Orientation">Gets or sets a value indicating how list items are arranged. Inherited from ListContainer.</field>
				/// <field name="selection" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of selected items. Inherited from ListContainer.</field>
				/// <field name="collapsible" type="Boolean">Gets or sets a value indicating whether the toolstrip can be collapsed. Inherited from ToolStrip.</field>
				/// <field name="expanded" type="Boolean">Gets a value indicating whether the ToolStrip is currently expanded. Inherited from ToolStrip.</field>
				/// <field name="scrollable" type="Boolean">Gets or sets a value indicating whether the ToolStrip displays scroll arrows when there is not enough room to display all items. Inherited from ToolStrip.</field>
				/// <field name="dragDrop" type="EventDispatcher">Raised when an item is dropped onto the control. Syntax: dragDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="dragOver" type="EventDispatcher">Raised when an item is dragged over the control. Syntax: dragOver.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemClick" type="EventDispatcher">Raised when an item is clicked. Syntax: itemClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDoubleClick" type="EventDispatcher">Raised when an item is double-clicked. Syntax: itemDoubleClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrag" type="EventDispatcher">Raised when an item is dragged. Syntax: itemDrag.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragEnd" type="EventDispatcher">Raised when a drag operation on an item is finished. Syntax: itemDragEnd.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragStart" type="EventDispatcher">Raised when a drag operation on an item is started. Syntax: itemDragStart.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDraw" type="EventDispatcher">Raised when an item is being drawn. Syntax: itemDraw.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrop" type="EventDispatcher">Raised when a drop operation is finished. Syntax: itemDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseDown" type="EventDispatcher">Raised when a mousedown event occurs in an item's element. Syntax: itemMouseDown.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseEnter" type="EventDispatcher">Raised when a mouseenter event occurs in an item's element. Syntax: itemMouseEnter.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseLeave" type="EventDispatcher">Raised when a mouseleave event occurs in an item's element. Syntax: itemMouseLeave.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanged" type="EventDispatcher">Raised when the items collection is changed. Syntax: itemsChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanging" type="EventDispatcher">Raised when the items collection is changing. Syntax: itemsChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanged" type="EventDispatcher">Raised when the selection collection is changed. Syntax: selectionChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanging" type="EventDispatcher">Raised when the selection collection is changing. Syntax: selectionChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
			},
			TemplatedItem: function () {
				/// <summary>Represents an item which can be templated.</summary>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the template.</field>
			},
			ToolStrip: function (element) {
				/// <summary>Represents a container of toolbar buttons.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="acceptDrop" type="MindFusion.Common.UI.ToolStripItem">Gets or sets the ToolStripItem instance that can be dropped.</field>
				/// <field name="collapsible" type="Boolean">Gets or sets a value indicating whether the toolstrip can be collapsed.</field>
				/// <field name="expanded" type="Boolean">Gets a value indicating whether the ToolStrip is currently expanded.</field>
				/// <field name="scrollable" type="Boolean">Gets or sets a value indicating whether the ToolStrip displays scroll arrows when there is not enough room to display all items.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets whether drag and drop capabilities are enabled. Inherited from ListContainer.</field>
				/// <field name="allowDrop" type="Boolean">Gets or sets whether the ListContainer control can be used as a drop target. Inherited from ListContainer.</field>
				/// <field name="allowMultipleSelection" type="Boolean">Gets or sets whether users are allowed to select more than one item at a time. Inherited from ListContainer.</field>
				/// <field name="content" type="HTMLElement">Gets a reference to the container's content element. Inherited from ListContainer.</field>
				/// <field name="items" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of ListItem-s. Inherited from ListContainer.</field>
				/// <field name="itemSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the list items. Inherited from ListContainer.</field>
				/// <field name="orientation" type="MindFusion.Common.UI.Orientation">Gets or sets a value indicating how list items are arranged. Inherited from ListContainer.</field>
				/// <field name="selection" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of selected items. Inherited from ListContainer.</field>
				/// <field name="dragDrop" type="EventDispatcher">Raised when an item is dropped onto the control. Syntax: dragDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="dragOver" type="EventDispatcher">Raised when an item is dragged over the control. Syntax: dragOver.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemClick" type="EventDispatcher">Raised when an item is clicked. Syntax: itemClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDoubleClick" type="EventDispatcher">Raised when an item is double-clicked. Syntax: itemDoubleClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrag" type="EventDispatcher">Raised when an item is dragged. Syntax: itemDrag.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragEnd" type="EventDispatcher">Raised when a drag operation on an item is finished. Syntax: itemDragEnd.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragStart" type="EventDispatcher">Raised when a drag operation on an item is started. Syntax: itemDragStart.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDraw" type="EventDispatcher">Raised when an item is being drawn. Syntax: itemDraw.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrop" type="EventDispatcher">Raised when a drop operation is finished. Syntax: itemDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseDown" type="EventDispatcher">Raised when a mousedown event occurs in an item's element. Syntax: itemMouseDown.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseEnter" type="EventDispatcher">Raised when a mouseenter event occurs in an item's element. Syntax: itemMouseEnter.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseLeave" type="EventDispatcher">Raised when a mouseleave event occurs in an item's element. Syntax: itemMouseLeave.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanged" type="EventDispatcher">Raised when the items collection is changed. Syntax: itemsChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanging" type="EventDispatcher">Raised when the items collection is changing. Syntax: itemsChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanged" type="EventDispatcher">Raised when the selection collection is changed. Syntax: selectionChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanging" type="EventDispatcher">Raised when the selection collection is changing. Syntax: selectionChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
			},
			ToolStripItem: function (type, title) {
				/// <summary>Represents an item in a ToolStrip control.</summary>
				/// <param name="type" type="ToolStripItemType" optional="true">Optional. ToolStripItemType. The type of this item.</param>
				/// <param name="title" type="String" optional="true">Optional. String. The display text of this item.</param>
				/// <field name="type" type="MindFusion.Common.UI.ToolStripItemType">Gets the type of this item.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the template. Inherited from TemplatedItem.</field>
				/// <field name="bounds" type="MindFusion.Common.UI.Rect">Gets the bounds of this ListItem. Inherited from ListItem.</field>
				/// <field name="contentElement" type="HTMLElement">Gets a reference to the item's content element. Inherited from ListItem.</field>
				/// <field name="cssClass" type="String">Gets or sets the css class of this ListItem. Inherited from ListItem.</field>
				/// <field name="data" type="Object">Gets or sets an object, holding custom user data. Inherited from ListItem.</field>
				/// <field name="dataIndex" type="Number">Gets or sets the unique index of this item. Inherited from ListItem.</field>
				/// <field name="element" type="HTMLElement">Gets a reference to the item's DOM element. Inherited from ListItem.</field>
				/// <field name="enabled" type="Boolean">Gets or sets a value indicating whether user interactions are allowed for this item. Inherited from ListItem.</field>
				/// <field name="imageSrc" type="String">Gets or sets the URL of the image displayed by this item. Inherited from ListItem.</field>
				/// <field name="interactive" type="Boolean">Gets or sets a value indicating whether drag and drop operations are allowed for this ListItem. Inherited from ListItem.</field>
				/// <field name="loaded" type="Boolean">Gets a value indicating whether this item is loaded and ready for interaction. Inherited from ListItem.</field>
				/// <field name="selected" type="Boolean">Gets a value indicating whether the item is selected. Inherited from ListItem.</field>
				/// <field name="size" type="MindFusion.Common.UI.Unit">Gets or sets the size of this item. Inherited from ListItem.</field>
				/// <field name="title" type="String">Gets or sets the display text of this item. Inherited from ListItem.</field>
				/// <field name="tooltip" type="String">Gets or sets the tooltip of this ListItem. Inherited from ListItem.</field>
				/// <field name="visible" type="Boolean">Gets or sets the visibility of this ListItem. Inherited from ListItem.</field>
			},
			Tooltip: function (target, title) {
				/// <summary>Represents a popup window, containing a custom message.</summary>
				/// <param name="target" type="HTMLElement">HTMLElement. The HTML element that will trigger the tooltip.</param>
				/// <param name="title" type="String" optional="true">Optional. String. The display text of the tooltip.</param>
				/// <field name="follow" type="Boolean">Gets or sets a value indicating whether the ToolTip will follow the mouse cursor.</field>
				/// <field name="offset" type="MindFusion.Common.UI.Point">Gets or sets the offset of the Tooltip.</field>
				/// <field name="position" type="MindFusion.Common.UI.TooltipPosition">Gets or sets the position of the Tooltip.</field>
				/// <field name="target" type="HTMLElement">Gets a reference to the tooltip's target element.</field>
				/// <field name="template" type="String">Gets or sets the ToolTip content template.</field>
				/// <field name="text" type="String">Gets or sets the text of the ToolTip.</field>
				/// <field name="trigger" type="MindFusion.Common.UI.TooltipTrigger">Gets or sets the event, which shows the ToolTip.</field>
				/// <field name="tooltipHide" type="EventDispatcher">Raised when the ToolTip is hidden. Syntax: tooltipHide.addEventListener( function(sender, args){} );</field>
				/// <field name="tooltipHiding" type="EventDispatcher">Raised when the ToolTip is hiding. Syntax: tooltipHiding.addEventListener( function(sender, args){} );</field>
				/// <field name="tooltipShow" type="EventDispatcher">Raised when the Tooltip is shown. Syntax: tooltipShow.addEventListener( function(sender, args){} );</field>
				/// <field name="tooltipShowing" type="EventDispatcher">Raised when the Tooltip is showing. Syntax: tooltipShowing.addEventListener( function(sender, args){} );</field>
			},
			TreeNode: function (title) {
				/// <summary>Represents an expandable ListItem.</summary>
				/// <param name="title" type="String" optional="true">Optional. String. The title of the new TreeNode.</param>
				/// <field name="expandable" type="Boolean">Gets a value indicating whether the TreeNode is expandable.</field>
				/// <field name="expanded" type="Boolean">Gets or sets a value indicating whether the TreeNode is expanded.</field>
				/// <field name="flatItems" type="MindFusion.Common.UI.List">Gets the collection of children items as a flat list.</field>
				/// <field name="items" type="MindFusion.Common.UI.ObservableCollection">Gets the children of the TreeNode.</field>
				/// <field name="level" type="Number">Gets the depth of the TreeNode in the TreeView hierarchy.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the template. Inherited from TemplatedItem.</field>
				/// <field name="bounds" type="MindFusion.Common.UI.Rect">Gets the bounds of this ListItem. Inherited from ListItem.</field>
				/// <field name="contentElement" type="HTMLElement">Gets a reference to the item's content element. Inherited from ListItem.</field>
				/// <field name="cssClass" type="String">Gets or sets the css class of this ListItem. Inherited from ListItem.</field>
				/// <field name="data" type="Object">Gets or sets an object, holding custom user data. Inherited from ListItem.</field>
				/// <field name="dataIndex" type="Number">Gets or sets the unique index of this item. Inherited from ListItem.</field>
				/// <field name="element" type="HTMLElement">Gets a reference to the item's DOM element. Inherited from ListItem.</field>
				/// <field name="enabled" type="Boolean">Gets or sets a value indicating whether user interactions are allowed for this item. Inherited from ListItem.</field>
				/// <field name="imageSrc" type="String">Gets or sets the URL of the image displayed by this item. Inherited from ListItem.</field>
				/// <field name="interactive" type="Boolean">Gets or sets a value indicating whether drag and drop operations are allowed for this ListItem. Inherited from ListItem.</field>
				/// <field name="loaded" type="Boolean">Gets a value indicating whether this item is loaded and ready for interaction. Inherited from ListItem.</field>
				/// <field name="selected" type="Boolean">Gets a value indicating whether the item is selected. Inherited from ListItem.</field>
				/// <field name="size" type="MindFusion.Common.UI.Unit">Gets or sets the size of this item. Inherited from ListItem.</field>
				/// <field name="title" type="String">Gets or sets the display text of this item. Inherited from ListItem.</field>
				/// <field name="tooltip" type="String">Gets or sets the tooltip of this ListItem. Inherited from ListItem.</field>
				/// <field name="visible" type="Boolean">Gets or sets the visibility of this ListItem. Inherited from ListItem.</field>
			},
			TreeView: function (element) {
				/// <summary>Represents a tree view control.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="acceptDrop" type="MindFusion.Common.UI.TreeNode">Gets or sets the TreeNode instance that can be dropped.</field>
				/// <field name="flatItems" type="MindFusion.Common.UI.List">Gets the collection of items as a flat list.</field>
				/// <field name="loadedItems" type="MindFusion.Common.UI.List">Gets the collection of loaded items as a flat list.</field>
				/// <field name="loadOnDemand" type="Boolean">Gets or sets a value indicating whether&#160;TreeNode-s DOM will be created only after their parent node is expanded.</field>
				/// <field name="toggleMode" type="MindFusion.Common.UI.ToggleMode">Gets or sets a value indicating how TreeNode-s expand/collapse will be triggered.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets whether drag and drop capabilities are enabled. Inherited from ListContainer.</field>
				/// <field name="allowDrop" type="Boolean">Gets or sets whether the ListContainer control can be used as a drop target. Inherited from ListContainer.</field>
				/// <field name="allowMultipleSelection" type="Boolean">Gets or sets whether users are allowed to select more than one item at a time. Inherited from ListContainer.</field>
				/// <field name="content" type="HTMLElement">Gets a reference to the container's content element. Inherited from ListContainer.</field>
				/// <field name="items" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of ListItem-s. Inherited from ListContainer.</field>
				/// <field name="itemSize" type="MindFusion.Common.UI.Unit">Gets or sets the size of the list items. Inherited from ListContainer.</field>
				/// <field name="orientation" type="MindFusion.Common.UI.Orientation">Gets or sets a value indicating how list items are arranged. Inherited from ListContainer.</field>
				/// <field name="selection" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of selected items. Inherited from ListContainer.</field>
				/// <field name="dragDrop" type="EventDispatcher">Raised when an item is dropped onto the control. Syntax: dragDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="dragOver" type="EventDispatcher">Raised when an item is dragged over the control. Syntax: dragOver.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemClick" type="EventDispatcher">Raised when an item is clicked. Syntax: itemClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDoubleClick" type="EventDispatcher">Raised when an item is double-clicked. Syntax: itemDoubleClick.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrag" type="EventDispatcher">Raised when an item is dragged. Syntax: itemDrag.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragEnd" type="EventDispatcher">Raised when a drag operation on an item is finished. Syntax: itemDragEnd.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDragStart" type="EventDispatcher">Raised when a drag operation on an item is started. Syntax: itemDragStart.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDraw" type="EventDispatcher">Raised when an item is being drawn. Syntax: itemDraw.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemDrop" type="EventDispatcher">Raised when a drop operation is finished. Syntax: itemDrop.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseDown" type="EventDispatcher">Raised when a mousedown event occurs in an item's element. Syntax: itemMouseDown.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseEnter" type="EventDispatcher">Raised when a mouseenter event occurs in an item's element. Syntax: itemMouseEnter.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemMouseLeave" type="EventDispatcher">Raised when a mouseleave event occurs in an item's element. Syntax: itemMouseLeave.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanged" type="EventDispatcher">Raised when the items collection is changed. Syntax: itemsChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="itemsChanging" type="EventDispatcher">Raised when the items collection is changing. Syntax: itemsChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanged" type="EventDispatcher">Raised when the selection collection is changed. Syntax: selectionChanged.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
				/// <field name="selectionChanging" type="EventDispatcher">Raised when the selection collection is changing. Syntax: selectionChanging.addEventListener( function(sender, args){} ); Inherited from ListContainer.</field>
			},
			ValueChangedEventArgs: function (oldValue, newValue) {
				/// <summary>Specifies data for valueChanged events.</summary>
				/// <param name="oldValue" type="Object">Object. Gets the value before the change.</param>
				/// <param name="newValue" type="Object">Object. The new value.</param>
				/// <field name="newValue" type="Object">Gets the new value.</field>
				/// <field name="oldValue" type="Object">Gets the value before the change.</field>
			},
			ValueChangingEventArgs: function (oldValue, newValue) {
				/// <summary>Specifies data for valueChanging events.</summary>
				/// <param name="oldValue" type="Object">Object. The value before the change.</param>
				/// <param name="newValue" type="Object">Object. The new value.</param>
				/// <field name="newValue" type="Object">Gets the new value.</field>
				/// <field name="oldValue" type="Object">Gets the value before the change.</field>
			},
			Window: function (element) {
				/// <summary>Represents a window with title and contents, which can be moved, resized and arranged interactively.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="allowClose" type="Boolean">Gets or sets a value indicating whether this Window can be closed.</field>
				/// <field name="allowDrag" type="Boolean">Gets or sets a value indicating whether this Window can be dragged.</field>
				/// <field name="allowMaximize" type="Boolean">Gets or sets a value indicating whether this Window can be maximized.</field>
				/// <field name="allowMinimize" type="Boolean">Gets or sets a value indicating whether this Window can be minimized.</field>
				/// <field name="allowPin" type="Boolean">Gets or sets a value indicating whether this Window can be pinned.</field>
				/// <field name="allowRefresh" type="Boolean">Gets or sets a value indicating whether this Window can be refreshed.</field>
				/// <field name="allowResize" type="Boolean">Gets or sets a value indicating whether this Window can be resized.</field>
				/// <field name="footer" type="HTMLDivElement">Gets a reference to the Window footer DOM element.</field>
				/// <field name="header" type="HTMLDivElement">Gets a reference to the Window header DOM element.</field>
				/// <field name="iconSrc" type="String">Gets or sets the url of the title icon.</field>
				/// <field name="minHeight" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed height of this Window.</field>
				/// <field name="minWidth" type="MindFusion.Common.UI.Unit">Gets or sets the minimum allowed width of this Window.</field>
				/// <field name="modal" type="Boolean">Gets or sets a value indicating whether this Window should be modal.</field>
				/// <field name="pinned" type="Boolean">Gets or sets a value, indicating whether this Window is pinned.</field>
				/// <field name="title" type="String">Gets or sets the title of this Window.</field>
				/// <field name="useFrameTitle" type="Boolean">Gets or sets a value indicating whether the window will display the title of its content iframe.</field>
				/// <field name="host" type="MindFusion.Common.UI.Container">Gets the host of this WindowHost. Inherited from WindowBase.</field>
				/// <field name="navigateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded in the control's content IFrame. Inherited from WindowBase.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the content template. Inherited from WindowBase.</field>
				/// <field name="templateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded as a control content template. Inherited from WindowBase.</field>
				/// <field name="windowState" type="MindFusion.Common.UI.WindowState">Gets or sets the state of this Window. Inherited from WindowBase.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip of the Window&#160;is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} );</field>
				/// <field name="dragEnd" type="EventDispatcher">Raised when drag operation is finished. Syntax: dragEnd.addEventListener( function(sender, args){} );</field>
				/// <field name="dragStart" type="EventDispatcher">Raised when a drag operation is started. Syntax: dragStart.addEventListener( function(sender, args){} );</field>
				/// <field name="headerClick" type="EventDispatcher">Raised when the Window header is clicked. Syntax: headerClick.addEventListener( function(sender, args){} );</field>
				/// <field name="resizeEnd" type="EventDispatcher">Raised when a resize operation is finished. Syntax: resizeEnd.addEventListener( function(sender, args){} );</field>
				/// <field name="resizeStart" type="EventDispatcher">Raised when a resize operation is started. Syntax: resizeStart.addEventListener( function(sender, args){} );</field>
				/// <field name="contentLoad" type="EventDispatcher">Raised when the windows's contents are loaded. Syntax: contentLoad.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanged" type="EventDispatcher">Raised when the window's state is changed. Syntax: stateChanged.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="stateChanging" type="EventDispatcher">Raised when the window's state is changing. Syntax: stateChanging.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClose" type="EventDispatcher">Raised when the Window is closed. Syntax: windowClose.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowClosing" type="EventDispatcher">Raised when the Window is closing. Syntax: windowClosing.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpen" type="EventDispatcher">Raised when the Window is opened. Syntax: windowOpen.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
				/// <field name="windowOpening" type="EventDispatcher">Raised when the Window is opening. Syntax: windowOpening.addEventListener( function(sender, args){} ); Inherited from WindowBase.</field>
			},
			WindowBase: function (element) {
				/// <summary>&#160;Represents a window, which can be either templated or rendered as an IFrame.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="host" type="MindFusion.Common.UI.Container">Gets the host of this WindowHost.</field>
				/// <field name="navigateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded in the control's content IFrame.</field>
				/// <field name="template" type="String">Gets or sets an HTML string, representing the content template.</field>
				/// <field name="templateUrl" type="String">Gets or sets a string, specifying the URL of the web page, that will be loaded as a control content template.</field>
				/// <field name="windowState" type="MindFusion.Common.UI.WindowState">Gets or sets the state of this Window.</field>
				/// <field name="contentLoad" type="EventDispatcher">Raised when the windows's contents are loaded. Syntax: contentLoad.addEventListener( function(sender, args){} );</field>
				/// <field name="stateChanged" type="EventDispatcher">Raised when the window's state is changed. Syntax: stateChanged.addEventListener( function(sender, args){} );</field>
				/// <field name="stateChanging" type="EventDispatcher">Raised when the window's state is changing. Syntax: stateChanging.addEventListener( function(sender, args){} );</field>
				/// <field name="windowClose" type="EventDispatcher">Raised when the Window is closed. Syntax: windowClose.addEventListener( function(sender, args){} );</field>
				/// <field name="windowClosing" type="EventDispatcher">Raised when the Window is closing. Syntax: windowClosing.addEventListener( function(sender, args){} );</field>
				/// <field name="windowOpen" type="EventDispatcher">Raised when the Window is opened. Syntax: windowOpen.addEventListener( function(sender, args){} );</field>
				/// <field name="windowOpening" type="EventDispatcher">Raised when the Window is opening. Syntax: windowOpening.addEventListener( function(sender, args){} );</field>
			},
			WindowHost: function (element) {
				/// <summary>Represents a container for Window objects.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="commandStrip" type="MindFusion.Common.UI.ToolStrip">Gets a reference to the default commands toolStrip.</field>
				/// <field name="maximizedStrip" type="MindFusion.Common.UI.ToolStrip">Gets a reference to the maximized windows ToolStrip.</field>
				/// <field name="minimizedStrip" type="MindFusion.Common.UI.ToolStrip">Gets a reference to the minimized windows ToolStrip.</field>
				/// <field name="windows" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of child Window-s.</field>
				/// <field name="activeChild" type="MindFusion.Common.UI.WindowBase">Gets the topmost child window. Inherited from Container.</field>
				/// <field name="children" type="MindFusion.Common.UI.ObservableCollection">Gets the collection of child windows. Inherited from Container.</field>
				/// <field name="content" type="HTMLDivElement">Gets a reference to the container's content element. Inherited from Container.</field>
				/// <field name="contentBounds" type="MindFusion.Common.UI.Rect">Gets the bounds of this container's content element. Inherited from Container.</field>
				/// <field name="contentRect" type="MindFusion.Common.UI.Rect">Gets the bounding rect of this container's content element. Inherited from Container.</field>
				/// <field name="windowClose" type="EventDispatcher">Raised when a child Window is closed. Syntax: windowClose.addEventListener( function(sender, args){} );</field>
				/// <field name="windowClosing" type="EventDispatcher">Raised when a child Window is being closed. Syntax: windowClosing.addEventListener( function(sender, args){} );</field>
				/// <field name="windowOpen" type="EventDispatcher">Raised when a child window is opened. Syntax: windowOpen.addEventListener( function(sender, args){} );</field>
				/// <field name="windowOpening" type="EventDispatcher">Raised when a child Window is being opened. Syntax: windowOpening.addEventListener( function(sender, args){} );</field>
				/// <field name="windowStateChanged" type="EventDispatcher">Raised when the state of a child window is modified. Syntax: windowStateChanged.addEventListener( function(sender, args){} );</field>
				/// <field name="windowStateChanging" type="EventDispatcher">Raised when the state of a child Window is being modified. Syntax: windowStateChanging.addEventListener( function(sender, args){} );</field>
			},
			YearView: function (element) {
				/// <summary>Displays a year, represented by a grid of month cells.</summary>
				/// <param name="element" type="HTMLElement" optional="true">Optional. HTMLElement. The control's associated Dom element.</param>
				/// <field name="date" type="Date">Gets the date of this view. Inherited from DateTimeView.</field>
				/// <field name="formatInfo" type="MindFusion.Common.UI.DateSettings">Gets the DateSettings object used to format and display date and time information in the view. Inherited from DateTimeView.</field>
				/// <field name="locale" type="MindFusion.Common.UI.Locale">Gets or sets the locale object used to format and display localizable information in the view. Inherited from DateTimeView.</field>
				/// <field name="buttonClick" type="EventDispatcher">Raised when a button in the command strip is clicked. Syntax: buttonClick.addEventListener( function(sender, args){} ); Inherited from DateTimeView.</field>
				/// <field name="cellClick" type="EventDispatcher">Raised when a date-time cell is clicked. Syntax: cellClick.addEventListener( function(sender, args){} ); Inherited from DateTimeView.</field>
			},
			__namespace: true
		},
		Control: function (element) {
			/// <summary>A base class for UI controls.</summary>
			/// <param name="element" type="HTMLElement" optional="true">Optional. Type: HTMLElement&#10;HTMLElement. The control's associated Dom element.</param>
			/// <field name="bounds" type="MindFusion.Common.Rect">Gets the bounds of this control.</field>
			/// <field name="cssClass" type="String">Gets or sets the css class of the control.</field>
			/// <field name="data" type="Object">Gets or sets an object, holding custom user data.</field>
			/// <field name="element" type="HTMLElement">Gets a reference to the control's element.</field>
			/// <field name="enabled" type="Boolean">Gets or sets a value indicating whether user interactions are allowed for this control.</field>
			/// <field name="height" type="MindFusion.Common.Unit">Gets or sets the height of this control.</field>
			/// <field name="left" type="MindFusion.Common.Unit">Gets or sets the X-coordinate of the location of this control.</field>
			/// <field name="licenseLocation" type="String">Gets or sets the URL of the control's license file.</field>
			/// <field name="loaded" type="Boolean">Gets a value indicating whether this control is loaded and ready for interaction.</field>
			/// <field name="rect" type="MindFusion.Common.Rect">Gets the bounding rect of this control.</field>
			/// <field name="theme" type="String">Gets or sets the current theme of the control.</field>
			/// <field name="top" type="MindFusion.Common.Unit">Gets or sets the Y-coordinate of the location of this control.</field>
			/// <field name="visible" type="Boolean">Gets or sets the visibility of this control.</field>
			/// <field name="width" type="MindFusion.Common.Unit">Gets or sets the width of this control.</field>
			/// <field name="controlLoad" type="EventDispatcher">Raised when the control is loaded. Syntax: controlLoad.addEventListener( function(sender, args){} );</field>
			/// <field name="controlUnload" type="EventDispatcher">Raised when the control is unloaded. Syntax: controlUnload.addEventListener( function(sender, args){} );</field>
			/// <field name="focus" type="EventDispatcher">Raised when the control is focused. Syntax: focus.addEventListener( function(sender, args){} );</field>
		},
		DateFormats: function () {
			/// <summary>Defines format string for dates and time.</summary>
			/// <field name="dayMonth" type="String">Gets or sets the day-month format string.</field>
			/// <field name="longDate" type="String">Gets or sets the long date format string.</field>
			/// <field name="longDateTime" type="String">Gets or sets the long date-time format string.</field>
			/// <field name="longTime" type="String">Gets or sets the long time format string.</field>
			/// <field name="shortDate" type="String">Gets or sets the short date format string.</field>
			/// <field name="shortDateTime" type="String">Gets or sets the short date-time format string.</field>
			/// <field name="shortTime" type="String">Gets or sets the short time format string.</field>
			/// <field name="yearMonth" type="String">Gets or sets the year-month format string.</field>
		},
		DateSettings: function (localeId) {
			/// <summary>Defines properties that allow customization of date-specific information.</summary>
			/// <param name="localeId" type="String">Type: String&#10;String. The string identifier of the locale.</param>
			/// <field name="dateFormats" type="MindFusion.Common.DateFormats">Gets the DateFormats object used to hold date and time format strings.</field>
			/// <field name="dateSeparator" type="String">Gets or sets the date separator character.</field>
			/// <field name="dayPeriodAM" type="String">Gets or sets the before noon time designator.</field>
			/// <field name="dayPeriodPM" type="String">Gets or sets the after noon time designator.</field>
			/// <field name="dayPeriods" type="Object">Gets an object containing the time designators.</field>
			/// <field name="days" type="Object">Gets an object containing lists of day names.</field>
			/// <field name="firstDayOfWeek" type="Number">Gets or sets a value indicating the first day of the week to use.</field>
			/// <field name="longDays" type="Array">Gets or sets a list of long day names.</field>
			/// <field name="longMonths" type="Array">Gets or sets a list of long month names.</field>
			/// <field name="months" type="Object">Gets an object containing lists of month names.</field>
			/// <field name="narrowDays" type="Array">Gets or sets a list of narrow day names.</field>
			/// <field name="narrowMonths" type="Array">Gets or sets a list of narrow month names.</field>
			/// <field name="shortDays" type="Array">Gets or sets a list of short month names.</field>
			/// <field name="shortMonths" type="Array">Gets or sets a list of short month names.</field>
			/// <field name="timeSeparator" type="String">Gets or sets the time separator character.</field>
		},
		EventDispatcher: function () {
			/// <summary>Represents a dispatcher for an event.</summary>
		},
		IdGenerator: function () {
			/// <summary>Generates unique ids.</summary>
		},
		Locale: function (id) {
			/// <summary>Provides culture-specific information.</summary>
			/// <param name="id" type="String" optional="true">Optional. Type: String&#10;String. The string identifier of the locale.</param>
			/// <field name="dateFormats" type="MindFusion.Common.DateFormats">Gets the DateFormats object used to hold date and time format strings.</field>
			/// <field name="dateSettings" type="MindFusion.Common.DateSettings">Gets the DateSettings object used to hold date-specific information.</field>
			/// <field name="id" type="String">Gets the string identifier of the locale.</field>
			/// <field name="strings" type="Object">Gets or sets the dictionary of custom strings.</field>
		},
		NotifyCollectionChangedAction: function () {
			/// <summary>Specifies the type of the collection changed action.</summary>
		},
		NotifyCollectionChangedEventArgs: function (action, changes, index) {
			/// <summary>Provides data for CollectionChanged events.</summary>
			/// <param name="action" type="NotifyCollectionChangedAction">NotifyCollectionChangedAction. The action that caused the event.</param>
			/// <param name="changes" type="Array" optional="true">Optional. Type: Array&#10;Array. The items affected by the change.</param>
			/// <param name="index" type="Number" optional="true">Optional. Type: Number&#10;Number. The index where the change occurred.</param>
			/// <field name="action" type="MindFusion.Common.NotifyCollectionChangedAction">Gets the action that caused the event.</field>
			/// <field name="index" type="Number">Gets the index where the change occurred.</field>
			/// <field name="newItems" type="Array">Gets the list of new items involved in the change.</field>
			/// <field name="oldItems" type="Array">Gets the list of the items affected by a Remove action.</field>
		},
		NotifyCollectionChangingEventArgs: function (action, changes, index) {
			/// <summary>Provides data for CollectionChanging events.</summary>
			/// <param name="action" type="NotifyCollectionChangedAction">NotifyCollectionChangedAction. The action that caused the event.</param>
			/// <param name="changes" type="Array" optional="true">Optional. Type: Array&#10;Array. The items affected by the change.</param>
			/// <param name="index" type="Number" optional="true">Optional. Type: Number&#10;Number. The index where the change occurred.</param>
			/// <field name="action" type="MindFusion.Common.NotifyCollectionChangedAction">Gets the action that caused the event.</field>
			/// <field name="newItems" type="Array">Gets the list of new items involved in the change.</field>
			/// <field name="oldItems" type="Array">Gets the list of the items affected by a Remove action.</field>
		},
		PropertyEventArgs: function (propertyName, oldValue, newValue) {
			/// <summary>Provides data for PropertyValueChanged events.</summary>
			/// <param name="propertyName" type="String">Type: String&#10;String. The name of the property that changed.</param>
			/// <param name="oldValue" type="Object">Type: Object&#10;Object. The old value of the property.</param>
			/// <param name="newValue" type="Object">Type: Object&#10;Object. The new value of the property.</param>
			/// <field name="newValue" type="Object">Gets the current value of the property.</field>
			/// <field name="oldValue" type="Object">Gets the value of the property before the change.</field>
			/// <field name="propertyName" type="String">Gets the name of the property that changed.</field>
		},
		UIControl: function (element) {
			/// <summary>Initializes a new instance of the Control class.</summary>
			/// <param name="element" type="HTMLElement" optional="true">Optional. Type: HTMLElement&#10;HTMLElement. The control's associated Dom element.</param>
		},
		Unit: function (value, type) {
			/// <summary>Represents a length measurement.</summary>
			/// <param name="value" type="Number" optional="true">Optional. Type: Number&#10;Number. The value of the unit.</param>
			/// <param name="type" type="UnitType" optional="true">Optional. Type: UnitType&#10;UnitType. The type of the unit.</param>
			/// <field name="isEmpty" type="Boolean">Gets a value representing whether this Unit instance has a set value.</field>
			/// <field name="type" type="MindFusion.Common.UnitType">The unit type.</field>
			/// <field name="value" type="Number">The unit value.</field>
		},
		__namespace: true
	},
	Controls: {
		CancelEventArgs: function () {
			/// <summary>Provides a value to use with cancellable events.</summary>
			/// <field name="cancel" type="Boolean">Gets or sets a value indicating whether to allow the current operation.</field>
			/// <field name="handled" type="Boolean">Gets or sets a value indicating whether the event has been handled. Inherited from EventArgs.</field>
		},
		Canvas: function () {
			/// <summary>Handles drawing on a CanvasRenderingContext2D.</summary>
			/// <field name="bounds" type="MindFusion.Controls.Rect">Gets the underlying Canvas element's logical bounds.</field>
			/// <field name="measureUnit" type="MindFusion.Controls.GraphicsUnit">Gets or sets the unit of measure used for logical coordinates.</field>
			/// <field name="minVisibleFontSize" type="Number">Gets or sets a threshold value that hides text if scaled font sizes become smaller.</field>
			/// <field name="scale" type="Number">Gets the current scale of this Canvas.</field>
			/// <field name="element" type="HTMLElement">Returns a reference to the control's DOM element. Inherited from Disposable.</field>
			/// <field name="enabled" type="Boolean">Gets or sets whether mouse events are enabled. Inherited from Disposable.</field>
		},
		CanvasControl: function (element, canvas) {
			/// <summary>The CanvasControl class represents a wrapper class for the HTML5 Canvas element.</summary>
			/// <param name="element" type="HTMLCanvasElement">HTMLCanvasElement. The Canvas DOM Element this CanvasControl is associated with.</param>
			/// <param name="canvas" type="Canvas" optional="true">Optional. Canvas. The Canvas instance this CanvasControl is associated with.</param>
			/// <field name="measureUnit" type="MindFusion.Controls.GraphicsUnit">Gets the unit of measure used for logical coordinates.</field>
			/// <field name="element" type="HTMLElement">Returns a reference to the control's DOM element. Inherited from Disposable.</field>
			/// <field name="enabled" type="Boolean">Gets or sets whether mouse events are enabled. Inherited from Disposable.</field>
		},
		Control: function (element) {
			/// <summary>A base class for MindFusion controls.</summary>
			/// <param name="element" type="HTMLElement">HTMLElement. The DOM Element this Control is associated with.</param>
			/// <field name="element" type="HTMLElement">Returns a reference to the control's DOM element.</field>
			/// <field name="enabled" type="Boolean">Gets or sets whether mouse events are enabled.</field>
		},
		Disposable: function () {
			/// <summary>Disposable abstract class.</summary>
			/// <field name="element" type="HTMLElement">Returns a reference to the control's DOM element.</field>
			/// <field name="enabled" type="Boolean">Gets or sets whether mouse events are enabled.</field>
		},
		DomUtils: function () {
			/// <summary>Contains DOM-related helper functions.</summary>
		},
		EventArgs: function () {
			/// <summary>The base type of classes that define arguments passed to event handler functions.</summary>
			/// <field name="handled" type="Boolean">Gets or sets a value indicating whether the event has been handled.</field>
		},
		Events: function () {
			/// <summary>Defines all events raised in the Controls namespace.</summary>
			/// <field name="controlLoaded" type="String">Raised when the control is loaded.</field>
		},
		ZoomControl: function (element) {
			/// <summary>The ZoomControl lets users zoom and pan a target view control interactively.</summary>
			/// <param name="element" type="HTMLCanvasElement">HTMLCanvasElement. The Canvas DOM Element this ZoomControl is associated with.</param>
			/// <field name="activeColor" type="String">Gets or sets the color used to render depressed buttons.</field>
			/// <field name="autoPostBack" type="Boolean">Gets or sets a value indicating whether the control will post back to the server when the control's value has changed.</field>
			/// <field name="backColor" type="String">Gets or sets the background color of the control.</field>
			/// <field name="borderColor" type="String">Gets or sets the color of ZoomControl elements' borders.</field>
			/// <field name="cornerRadius" type="Number">Gets or sets the corner radius of rounded child elements.</field>
			/// <field name="enabled" type="Boolean">Gets or sets whether mouse events are enabled.</field>
			/// <field name="fill" type="String">Gets or sets the color used to fill the ZoomControl elements.</field>
			/// <field name="innerColor" type="String">Gets or sets the color of plus, minus and arrow icons.</field>
			/// <field name="maxZoomFactor" type="Number">Gets or sets the maximum zoom level allowed to set through this control.</field>
			/// <field name="minZoomFactor" type="Number">Gets or sets the minimum zoom level allowed to set through this control.</field>
			/// <field name="padding" type="Number">Gets or sets the padding of the control's contents.</field>
			/// <field name="scrollStep" type="Number">Gets or sets the scroll offset added when users click the pan arrows.</field>
			/// <field name="shadowColor" type="String">Gets or sets the color of the control elements' shadow.</field>
			/// <field name="showLabel" type="Boolean">Gets or sets a value indicating whether the label that shows the current zoom level should be visible.</field>
			/// <field name="snapToZoomStep" type="Boolean">Gets or sets a value indicating whether the trackbar should snap to zoomStep values when dragged.</field>
			/// <field name="target" type="MindFusion.Controls.Control">Gets or sets the control modified by this ZoomControl.</field>
			/// <field name="textColor" type="String">Gets or sets the color of the the label that shows the current zoom level.</field>
			/// <field name="tickPosition" type="MindFusion.Controls.TickPosition">Gets or sets the current tick position of the trackbar.</field>
			/// <field name="zoomFactor" type="Number">Gets or sets the zoom factor.</field>
			/// <field name="zoomStep" type="Number">Gets or sets the amount by which to change zoom level when + and - buttons are clicked.</field>
			/// <field name="element" type="HTMLElement">Returns a reference to the control's DOM element. Inherited from Disposable.</field>
			/// <field name="measureUnit" type="MindFusion.Controls.GraphicsUnit">Gets the unit of measure used for logical coordinates. Inherited from CanvasControl.</field>
		},
		__namespace: true
	},
	Drawing: {
		Border3D: function (rect) {
			/// <summary>Represents a 3D border.</summary>
			/// <param name="rect" type="Rect">Rect. A Rect instance containing the border coordinates.</param>
		},
		Component: function () {
			/// <summary>Represents components in CompositeNode visual tree.</summary>
			/// <field name="visibility" type="MindFusion.Drawing.Visibility">Gets or sets the visibility of this component. Inherited from ComponentBase.</field>
		},
		ComponentBase: function () {
			/// <summary>A base class for components in CompositeNode visual tree.</summary>
			/// <field name="visibility" type="MindFusion.Drawing.Visibility">Gets or sets the visibility of this component.</field>
		},
		Container: function () {
			/// <summary>Represents container components in drawing tree.</summary>
			/// <field name="visibility" type="MindFusion.Drawing.Visibility">Gets or sets the visibility of this component. Inherited from ComponentBase.</field>
		},
		DrawingUtils: function () {
			/// <summary>Contains drawing-related helper functions.</summary>
		},
		Ellipse: function (x, y, width, height) {
			/// <summary>Represents an Ellipse.</summary>
			/// <param name="x" type="Number">Number. The X-coordinate of the top left corner of the Ellipse.</param>
			/// <param name="y" type="Number">Number. The Y-coordinate of the top left corner of the Ellipse.</param>
			/// <param name="width" type="Number">Number. The width of the Ellipse.</param>
			/// <param name="height" type="Number">Number. The height of the Ellipse.</param>
			/// <field name="height" type="Number">Gets or sets the height of the ellipse.</field>
			/// <field name="width" type="Number">Gets or sets the width of the ellipse.</field>
			/// <field name="x" type="Number">Gets or sets the x-coordinate of the upper-left corner of the ellipse.</field>
			/// <field name="y" type="Number">Gets or sets the y-coordinate of the upper-left corner of the ellipse.</field>
		},
		Font: function (name, size, bold, italic, underline) {
			/// <summary>Represents a font.</summary>
			/// <param name="name" type="String">String. The font name.</param>
			/// <param name="size" type="Number" optional="true">Optional. Number. The font size.</param>
			/// <param name="bold" type="Boolean | FontStyle" optional="true">Optional. Boolean | FontStyle. true if this font is bold, or false otherwise.</param>
			/// <param name="italic" type="Boolean" optional="true">Optional. Boolean. true if this font is italic, or false otherwise.</param>
			/// <param name="underline" type="Boolean" optional="true">Optional. Boolean. true if this font is underlined, or false otherwise.</param>
			/// <field name="bold" type="Boolean">Gets whether the font is bold.</field>
			/// <field name="fontStyle" type="MindFusion.Drawing.FontStyle">Gets or sets the style of this font.</field>
			/// <field name="italic" type="Boolean">Gets whether the font is italic.</field>
			/// <field name="name" type="String">Gets or sets the name of this font.</field>
			/// <field name="size" type="Number">Gets or sets the size of this font.</field>
			/// <field name="underline" type="Boolean">Gets whether the font is underlined.</field>
		},
		GraphicsUnit: function () {
			/// <summary>Specifies the unit of measure for length and size properties.</summary>
			/// <field name="Centimeter" type="Number">Specifies the centimeter as the unit of measure.</field>
			/// <field name="Display" type="Number">Specifies the display unit as the unit of measure.</field>
			/// <field name="Document" type="Number">Specifies the document unit as the unit of measure.</field>
			/// <field name="Inch" type="Number">Specifies the inch as the unit of measure.</field>
			/// <field name="Millimeter" type="Number">Specifies the millimeter as the unit of measure.</field>
			/// <field name="Percent" type="Number">Specifies the world coordinate system unit as the unit of measure.</field>
			/// <field name="Pixel" type="Number">Specifies the pixel unit as the unit of measure.</field>
			/// <field name="Point" type="Number">Specifies a printer's point as the unit of measure.</field>
			/// <field name="World" type="Number">Specifies the world coordinate system unit as the unit of measure.</field>
			/// <field name="WpfPoint" type="Number">Specifies the WpfPoint unit as the unit of measure.</field>
		},
		Image: function (bounds) {
			/// <summary>Represents an image.</summary>
			/// <param name="bounds" type="Rect">Rect. The bounds of the image.</param>
		},
		Path: function (pathString) {
			/// <summary>Represents a path.</summary>
			/// <param name="pathString" type="String" optional="true">Optional. String. A string representing the path figures.</param>
			/// <field name="brush" type="Object">Gets or sets the brush used to fill a closed path.</field>
			/// <field name="pen" type="Object">Gets or sets the pen used to draw the path.</field>
			/// <field name="text" type="String">Gets or sets the text displayed inside this path.</field>
		},
		Point: function (x, y) {
			/// <summary>Represents a point.</summary>
			/// <param name="x" type="Number">The X-coordinate of the Point.</param>
			/// <param name="y" type="Number">The Y-coordinate of the Point.</param>
			/// <field name="x" type="Number">Gets or sets the x-coordinate of the point.</field>
			/// <field name="y" type="Number">Gets or sets the y-coordinate of the point.</field>
		},
		Rect: function () {
			/// <summary>Represents a rectangle.</summary>
			/// <field name="height" type="Number">Gets or sets the height of the rectangle.</field>
			/// <field name="width" type="Number">Gets or sets the width of the rectangle.</field>
			/// <field name="x" type="Number">Gets or sets the x-coordinate of the upper-left corner of the rectangle.</field>
			/// <field name="y" type="Number">Gets or sets the y-coordinate of the upper-left corner of the rectangle.</field>
		},
		Size: function (width, height) {
			/// <summary>Represents the size of 2D object.</summary>
			/// <param name="width" type="Number">Number. Specifies width.</param>
			/// <param name="height" type="Number">Number. Specifies height.</param>
			/// <field name="height" type="Number">Gets or sets the size height.</field>
			/// <field name="width" type="Number">Gets or sets the size width.</field>
		},
		StringFormat: function () {
			/// <summary>Encapsulates text layout information.</summary>
			/// <field name="alignment" type="MindFusion.Drawing.StringAlignment">Gets or sets the horizontal alignment of the text.</field>
			/// <field name="lineAlignment" type="MindFusion.Drawing.StringAlignment">Gets or sets the vertical alignment of the text.</field>
		},
		Text: function (text, bounds) {
			/// <summary>Represents a text container.</summary>
			/// <param name="text" type="String">String. The text to be displayed in the container.</param>
			/// <param name="bounds" type="Rect">Rect. The bounds of the container.</param>
			/// <field name="font" type="MindFusion.Drawing.Font">Gets or sets the font used to render text.</field>
			/// <field name="rotationAngle" type="Number">Gets a value indicating the rotation of the text container.</field>
			/// <field name="text" type="String">Gets or sets the text to render.</field>
		},
		Thickness: function () {
			/// <summary>Describes the thickness of a rectangular frame.</summary>
			/// <field name="bottom" type="Number">Gets or sets the width of the bottom side of the frame.</field>
			/// <field name="isRelative" type="Boolean">Gets or sets a flag indicating whether the thickness properties are expressed as relative or absolute quantities.</field>
			/// <field name="left" type="Number">Gets or sets the width of the left side of the frame.</field>
			/// <field name="right" type="Number">Gets or sets the width of the right side of the frame.</field>
			/// <field name="top" type="Number">Gets or sets the width of the top side of the frame.</field>
		},
		Vector: function (x, y) {
			/// <summary>Represents displacement in 2D space.</summary>
			/// <param name="x" type="Number">Number. The X-coordinate of the Vector.</param>
			/// <param name="y" type="Number">Number. The Y-coordinate of the Vector.</param>
		},
		Video: function (bounds) {
			/// <summary>A component that displays video stream.</summary>
			/// <param name="bounds" type="Rect">Rect. The bounds of the Video.</param>
			/// <field name="mediaLocation" type="String">Gets or sets URL of the video stream displayed in this component.</field>
		},
		__namespace: true
	},
	Keyboard: {
		Key: function (config) {
			/// <summary>Represents a key in the keyboard.</summary>
			/// <param name="config" type="Object">An object literal whose fields are assigned to respective Key properties.</param>
		},
		KeyboardLayout: function () {
			/// <summary>Defines layout of keyboard keys.</summary>
		},
		KeyboardState: function () {
			/// <summary>Specifies state of modifier keys.</summary>
		},
		VirtualKeyboard: function (element) {
			/// <summary>Implements a reusable Virtual Keyboard component.</summary>
			/// <param name="element" type="HTMLDivElement" optional="true">Optional. HTMLDivElement. The control's associated Dom element.</param>
			/// <field name="autoReleaseModifierKeys" type="Boolean">Gets or sets a value indicating whether pressing a regular key should automatically release modifier keys such as shift, alt, control etc. (except CapsLock).</field>
			/// <field name="autoRepeat" type="Boolean">Gets or sets a value indicating whether the component should synthesize keyboard events repeatedly when a virtual key is pressed down, until the key is released.</field>
			/// <field name="inputLocale" type="String">Gets or sets the current input language.</field>
			/// <field name="layout" type="MindFusion.Keyboard.KeyboardLayout">Gets or sets the current keyboard layout.</field>
			/// <field name="layoutMode" type="MindFusion.Keyboard.KeyboardMode">Gets or sets the current keyboard layout mode.</field>
			/// <field name="scaleToFitParent" type="Boolean">Gets or sets a value indicating whether the keyboard scales to fit inside its parent element.</field>
			/// <field name="theme" type="String">Gets or sets the current theme of the control.</field>
			/// <field name="keyPressed" type="EventDispatcher">Raised when a key is pressed. Syntax: keyPressed.addEventListener( function(sender, args){} );</field>
		},
		__namespace: true
	},
	__namespace: true
};

MindFusion.Common.Collections.IEnumerable.prototype = {
	add: function(item) {
		/// <summary>Adds an object to the end of the collection.</summary>
		/// <param name="item" type="Object">Object. The object to add.</param>
	},
	addRange: function(range) {
		/// <summary>Adds a range of elements to the end of the collection.</summary>
		/// <param name="range" type="Array">Array. The range to add.</param>
	},
	clear: function() {
		/// <summary>Clears the collection.</summary>
	},
	clone: function() {
		/// <summary>Creates a copy of the collection.</summary>
		/// <returns type="IEnumerable">IEnumerable. A copy of this collection.</returns>
	},
	contains: function(item) {
		/// <summary>Checks if the given element is present in the collection.</summary>
		/// <param name="item" type="Object">Object. The object to check for.</param>
		/// <returns type="Boolean">Boolean. True if the element is found, otherwise false.</returns>
	},
	copyTo: function(destination, length, sourceIndex, destinationIndex) {
		/// <summary>Copies a range of elements from this collection to a destination collection.</summary>
		/// <param name="destination" type="IEnumerable">IEnumerable. The destination collection.</param>
		/// <param name="length" type="Number">Number. The length of the range to copy.</param>
		/// <param name="sourceIndex" type="Number" optional="true">Optional. Number. The starting index of the range to copy.</param>
		/// <param name="destinationIndex" type="Number" optional="true">Optional. Number. The index at which the range should be copied.</param>
	},
	count: function() {
		/// <summary>Gets the number of elements.</summary>
		/// <returns type="Number">Number. The number of elements.</returns>
	},
	first: function() {
		/// <summary>Returns the first element in the collection.</summary>
		/// <returns type="Object">Object. The first element in the collection.</returns>
	},
	forEach: function(callback, context) {
		/// <summary>Executes a provided function once for each element.</summary>
		/// <param name="callback" type="function">function. A function to execute for each element.</param>
		/// <param name="context" type="Object">Object. The invokation context.</param>
	},
	indexOfItem: function(obj, fromIndex) {
		/// <summary>Gets the index of a given object in a collection.</summary>
		/// <param name="obj" type="Object">Object. The object to look for.</param>
		/// <param name="fromIndex" type="Number" optional="true">Optional. Number. The starting index to search from.</param>
		/// <returns type="Number">Number. The index of the object, or -1 if the object is not present in the collection.</returns>
	},
	insert: function(index, item) {
		/// <summary>Adds an element to the collection at the specified index.</summary>
		/// <param name="index" type="Number">Number. The index.</param>
		/// <param name="item" type="Object">Object. The object to add.</param>
	},
	item: function(index) {
		/// <summary>Gets the element at the given index.</summary>
		/// <param name="index" type="Number">Number. The index.</param>
		/// <returns type="Object">Object. The element at the given index.</returns>
	},
	items: function() {
		/// <summary>Gets the collection as an array.</summary>
		/// <returns type="Array">Array. The underlying array data structure of the collection.</returns>
	},
	last: function() {
		/// <summary>Returns the last element in the collection.</summary>
		/// <returns type="Object">Object. The last element in the collection.</returns>
	},
	max: function(selector) {
		/// <summary>Invokes a transform function on each item and returns the maximum value in a sequence of numbers.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="Number">Number. The maximum number in the sequence.</returns>
	},
	min: function(selector) {
		/// <summary>Invokes a transform function on each item and returns theminimum value in a sequence of numbers.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="Number">Number. The minimum number in the sequence.</returns>
	},
	remove: function(item) {
		/// <summary>Removes an element from the collection.</summary>
		/// <param name="item" type="Object">Object. The object to remove.</param>
	},
	removeAt: function(index) {
		/// <summary>Removes the element at the given index.</summary>
		/// <param name="index" type="Number">Number. The index.</param>
	},
	removeRange: function(index, count) {
		/// <summary>Removes a range of elements starting from the given index.</summary>
		/// <param name="index" type="Number">Number. The starting index of the range.</param>
		/// <param name="count" type="Number">Number. The length of the range.</param>
	},
	reverse: function() {
		/// <summary>Gets the collection as an array in reverse order.</summary>
		/// <returns type="Array">Array. The underlying array data structure of the collection in reverse order.</returns>
	},
	select: function(selector) {
		/// <summary>Projects each element of a sequence into a new form.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="IEnumerable">IEnumerable. An collection whose elements are the resultof invoking the transform function on each element.</returns>
	},
	sort: function(compareFn) {
		/// <summary>Sorts the underlying array.</summary>
		/// <param name="compareFn" type="function" optional="true">Optional. function. The comparing function.</param>
	},
	sum: function(selector) {
		/// <summary>Computes the sum of the sequence of number values that are obtained by invoking a transform function on each element.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="Number">Number. The sum of the number values in the sequence.</returns>
	},
	toArray: function() {
		/// <summary>Returns a new Object array, containing the contents of the collection.</summary>
		/// <returns type="Array">Array. The array.</returns>
	},
	where: function(selector) {
		/// <summary>Filters a sequence of values based on a predicate.</summary>
		/// <param name="selector" type="function">function. A function to test each element for a condition.</param>
		/// <returns type="IEnumerable">IEnumerable. An collection that contains elements from the input sequence that satisfy the condition.</returns>
	}
};
MindFusion.Common.Collections.IEnumerable.__class = true;

MindFusion.Common.Collections.List.prototype = {
	add: function(item) {
		/// <summary>Adds an object to the end of the collection. Inherited from IEnumerable.</summary>
		/// <param name="item" type="Object">Object. The object to add.</param>
	},
	addRange: function(range) {
		/// <summary>Adds a range of elements to the end of the collection. Inherited from IEnumerable.</summary>
		/// <param name="range" type="Array">Array. The range to add.</param>
	},
	clear: function() {
		/// <summary>Clears the collection. Inherited from IEnumerable.</summary>
	},
	clone: function() {
		/// <summary>Creates a copy of the collection. Inherited from IEnumerable.</summary>
		/// <returns type="IEnumerable">IEnumerable. A copy of this collection.</returns>
	},
	contains: function(item) {
		/// <summary>Checks if the given element is present in the collection. Inherited from IEnumerable.</summary>
		/// <param name="item" type="Object">Object. The object to check for.</param>
		/// <returns type="Boolean">Boolean. True if the element is found, otherwise false.</returns>
	},
	copyTo: function(destination, length, sourceIndex, destinationIndex) {
		/// <summary>Copies a range of elements from this collection to a destination collection. Inherited from IEnumerable.</summary>
		/// <param name="destination" type="IEnumerable">IEnumerable. The destination collection.</param>
		/// <param name="length" type="Number">Number. The length of the range to copy.</param>
		/// <param name="sourceIndex" type="Number" optional="true">Optional. Number. The starting index of the range to copy.</param>
		/// <param name="destinationIndex" type="Number" optional="true">Optional. Number. The index at which the range should be copied.</param>
	},
	count: function() {
		/// <summary>Gets the number of elements. Inherited from IEnumerable.</summary>
		/// <returns type="Number">Number. The number of elements.</returns>
	},
	first: function() {
		/// <summary>Returns the first element in the collection. Inherited from IEnumerable.</summary>
		/// <returns type="Object">Object. The first element in the collection.</returns>
	},
	forEach: function(callback, context) {
		/// <summary>Executes a provided function once for each element. Inherited from IEnumerable.</summary>
		/// <param name="callback" type="function">function. A function to execute for each element.</param>
		/// <param name="context" type="Object">Object. The invokation context.</param>
	},
	indexOfItem: function(obj, fromIndex) {
		/// <summary>Gets the index of a given object in a collection. Inherited from IEnumerable.</summary>
		/// <param name="obj" type="Object">Object. The object to look for.</param>
		/// <param name="fromIndex" type="Number" optional="true">Optional. Number. The starting index to search from.</param>
		/// <returns type="Number">Number. The index of the object, or -1 if the object is not present in the collection.</returns>
	},
	insert: function(index, item) {
		/// <summary>Adds an element to the collection at the specified index. Inherited from IEnumerable.</summary>
		/// <param name="index" type="Number">Number. The index.</param>
		/// <param name="item" type="Object">Object. The object to add.</param>
	},
	item: function(index) {
		/// <summary>Gets the element at the given index. Inherited from IEnumerable.</summary>
		/// <param name="index" type="Number">Number. The index.</param>
		/// <returns type="Object">Object. The element at the given index.</returns>
	},
	items: function() {
		/// <summary>Gets the collection as an array. Inherited from IEnumerable.</summary>
		/// <returns type="Array">Array. The underlying array data structure of the collection.</returns>
	},
	last: function() {
		/// <summary>Returns the last element in the collection. Inherited from IEnumerable.</summary>
		/// <returns type="Object">Object. The last element in the collection.</returns>
	},
	max: function(selector) {
		/// <summary>Invokes a transform function on each item and returns the maximum value in a sequence of numbers. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="Number">Number. The maximum number in the sequence.</returns>
	},
	min: function(selector) {
		/// <summary>Invokes a transform function on each item and returns theminimum value in a sequence of numbers. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="Number">Number. The minimum number in the sequence.</returns>
	},
	remove: function(item) {
		/// <summary>Removes an element from the collection. Inherited from IEnumerable.</summary>
		/// <param name="item" type="Object">Object. The object to remove.</param>
	},
	removeAt: function(index) {
		/// <summary>Removes the element at the given index. Inherited from IEnumerable.</summary>
		/// <param name="index" type="Number">Number. The index.</param>
	},
	removeRange: function(index, count) {
		/// <summary>Removes a range of elements starting from the given index. Inherited from IEnumerable.</summary>
		/// <param name="index" type="Number">Number. The starting index of the range.</param>
		/// <param name="count" type="Number">Number. The length of the range.</param>
	},
	reverse: function() {
		/// <summary>Gets the collection as an array in reverse order. Inherited from IEnumerable.</summary>
		/// <returns type="Array">Array. The underlying array data structure of the collection in reverse order.</returns>
	},
	select: function(selector) {
		/// <summary>Projects each element of a sequence into a new form. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="IEnumerable">IEnumerable. An collection whose elements are the resultof invoking the transform function on each element.</returns>
	},
	sort: function(compareFn) {
		/// <summary>Sorts the underlying array. Inherited from IEnumerable.</summary>
		/// <param name="compareFn" type="function" optional="true">Optional. function. The comparing function.</param>
	},
	sum: function(selector) {
		/// <summary>Computes the sum of the sequence of number values that are obtained by invoking a transform function on each element. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="Number">Number. The sum of the number values in the sequence.</returns>
	},
	toArray: function() {
		/// <summary>Returns a new Object array, containing the contents of the collection. Inherited from IEnumerable.</summary>
		/// <returns type="Array">Array. The array.</returns>
	},
	where: function(selector) {
		/// <summary>Filters a sequence of values based on a predicate. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A function to test each element for a condition.</param>
		/// <returns type="IEnumerable">IEnumerable. An collection that contains elements from the input sequence that satisfy the condition.</returns>
	}
};
MindFusion.Common.Collections.List.__class = true;

MindFusion.Common.Collections.ObservableCollection.prototype = {
	add: function(item) {
		/// <summary>Adds an item to the collection.</summary>
		/// <param name="item" type="Object">Object. The item to add.</param>
	},
	clear: function() {
		/// <summary>Clears the collection.</summary>
	},
	insert: function(index, item) {
		/// <summary>Adds an item to the collection at the specified index.</summary>
		/// <param name="index" type="Number">Number. The index.</param>
		/// <param name="item" type="Object">Object. The object to add.</param>
	},
	remove: function(item) {
		/// <summary>Deletes an item from the collection.</summary>
		/// <param name="item" type="Object">Object. The item to remove.</param>
	},
	removeAt: function(itemIndex) {
		/// <summary>Deletes the item at the specified index.</summary>
		/// <param name="itemIndex" type="Number">Number. The index to remove at.</param>
	},
	removeRange: function(index, count) {
		/// <summary>Deletes a range of items from the collection.</summary>
		/// <param name="index" type="Number">Number. The starting index of the range to remove.</param>
		/// <param name="count" type="Number">Number. The length of the range to remove.</param>
	},
	addRange: function(range) {
		/// <summary>Adds a range of elements to the end of the collection. Inherited from IEnumerable.</summary>
		/// <param name="range" type="Array">Array. The range to add.</param>
	},
	clone: function() {
		/// <summary>Creates a copy of the collection. Inherited from IEnumerable.</summary>
		/// <returns type="IEnumerable">IEnumerable. A copy of this collection.</returns>
	},
	contains: function(item) {
		/// <summary>Checks if the given element is present in the collection. Inherited from IEnumerable.</summary>
		/// <param name="item" type="Object">Object. The object to check for.</param>
		/// <returns type="Boolean">Boolean. True if the element is found, otherwise false.</returns>
	},
	copyTo: function(destination, length, sourceIndex, destinationIndex) {
		/// <summary>Copies a range of elements from this collection to a destination collection. Inherited from IEnumerable.</summary>
		/// <param name="destination" type="IEnumerable">IEnumerable. The destination collection.</param>
		/// <param name="length" type="Number">Number. The length of the range to copy.</param>
		/// <param name="sourceIndex" type="Number" optional="true">Optional. Number. The starting index of the range to copy.</param>
		/// <param name="destinationIndex" type="Number" optional="true">Optional. Number. The index at which the range should be copied.</param>
	},
	count: function() {
		/// <summary>Gets the number of elements. Inherited from IEnumerable.</summary>
		/// <returns type="Number">Number. The number of elements.</returns>
	},
	first: function() {
		/// <summary>Returns the first element in the collection. Inherited from IEnumerable.</summary>
		/// <returns type="Object">Object. The first element in the collection.</returns>
	},
	forEach: function(callback, context) {
		/// <summary>Executes a provided function once for each element. Inherited from IEnumerable.</summary>
		/// <param name="callback" type="function">function. A function to execute for each element.</param>
		/// <param name="context" type="Object">Object. The invokation context.</param>
	},
	indexOfItem: function(obj, fromIndex) {
		/// <summary>Gets the index of a given object in a collection. Inherited from IEnumerable.</summary>
		/// <param name="obj" type="Object">Object. The object to look for.</param>
		/// <param name="fromIndex" type="Number" optional="true">Optional. Number. The starting index to search from.</param>
		/// <returns type="Number">Number. The index of the object, or -1 if the object is not present in the collection.</returns>
	},
	item: function(index) {
		/// <summary>Gets the element at the given index. Inherited from IEnumerable.</summary>
		/// <param name="index" type="Number">Number. The index.</param>
		/// <returns type="Object">Object. The element at the given index.</returns>
	},
	items: function() {
		/// <summary>Gets the collection as an array. Inherited from IEnumerable.</summary>
		/// <returns type="Array">Array. The underlying array data structure of the collection.</returns>
	},
	last: function() {
		/// <summary>Returns the last element in the collection. Inherited from IEnumerable.</summary>
		/// <returns type="Object">Object. The last element in the collection.</returns>
	},
	max: function(selector) {
		/// <summary>Invokes a transform function on each item and returns the maximum value in a sequence of numbers. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="Number">Number. The maximum number in the sequence.</returns>
	},
	min: function(selector) {
		/// <summary>Invokes a transform function on each item and returns theminimum value in a sequence of numbers. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="Number">Number. The minimum number in the sequence.</returns>
	},
	reverse: function() {
		/// <summary>Gets the collection as an array in reverse order. Inherited from IEnumerable.</summary>
		/// <returns type="Array">Array. The underlying array data structure of the collection in reverse order.</returns>
	},
	select: function(selector) {
		/// <summary>Projects each element of a sequence into a new form. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="IEnumerable">IEnumerable. An collection whose elements are the resultof invoking the transform function on each element.</returns>
	},
	sort: function(compareFn) {
		/// <summary>Sorts the underlying array. Inherited from IEnumerable.</summary>
		/// <param name="compareFn" type="function" optional="true">Optional. function. The comparing function.</param>
	},
	sum: function(selector) {
		/// <summary>Computes the sum of the sequence of number values that are obtained by invoking a transform function on each element. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A transform function to invoke on each element.</param>
		/// <returns type="Number">Number. The sum of the number values in the sequence.</returns>
	},
	toArray: function() {
		/// <summary>Returns a new Object array, containing the contents of the collection. Inherited from IEnumerable.</summary>
		/// <returns type="Array">Array. The array.</returns>
	},
	where: function(selector) {
		/// <summary>Filters a sequence of values based on a predicate. Inherited from IEnumerable.</summary>
		/// <param name="selector" type="function">function. A function to test each element for a condition.</param>
		/// <returns type="IEnumerable">IEnumerable. An collection that contains elements from the input sequence that satisfy the condition.</returns>
	}
};
MindFusion.Common.Collections.ObservableCollection.__class = true;

MindFusion.Common.Control.prototype = {
	attach: function() {
		/// <summary>Attach control event handlers.</summary>
	},
	detach: function() {
		/// <summary>Detach control event handlers.</summary>
	},
	dispose: function() {
		/// <summary>Dispose the control.</summary>
	},
	draw: function() {
		/// <summary>Draws the control.</summary>
		/// <returns type="HTMLElement">HTMLElement. The control DOM element.</returns>
	},
	render: function() {
		/// <summary>Draws the control and prepares it for user interaction.</summary>
	}
};
MindFusion.Common.Control.__class = true;

MindFusion.Common.Control.find = function(id) {
	/// <summary>Returns the control with the specified ID.</summary>
	/// <param name="id" type="String">String. The ID.</param>
	/// <returns type="Control">Control. The control with the specified ID, if found; otherwise, null.</returns>
};

MindFusion.Common.DateFormats.prototype = {
};
MindFusion.Common.DateFormats.__class = true;

MindFusion.Common.DateSettings.prototype = {
	fromJson: function(json) {
		/// <summary>Deserializes the settings from a JSON string.</summary>
		/// <param name="json" type="String">String. A string containing data for the settings.</param>
	}
};
MindFusion.Common.DateSettings.__class = true;

MindFusion.Common.EventDispatcher.prototype = {
	addEventListener: function(handler) {
		/// <summary>Subcribes an event listener to this event.</summary>
		/// <param name="handler" type="function">function. The handler function.</param>
	},
	raiseEvent: function(sender, args) {
		/// <summary>Raises this event.</summary>
		/// <param name="sender" type="Object">Object. The source of the event.</param>
		/// <param name="args" type="Object">Object. An object, containing event data.</param>
	},
	removeEventListener: function(handler) {
		/// <summary>Removes an event listener from this event.</summary>
		/// <param name="handler" type="function">function. The handler function.</param>
	}
};
MindFusion.Common.EventDispatcher.__class = true;

MindFusion.Common.IdGenerator.prototype = {
};
MindFusion.Common.IdGenerator.__class = true;

MindFusion.Common.IdGenerator.generate = function(prefix) {
	/// <summary>Generates a new id that starts with the specified prefix.</summary>
	/// <param name="prefix" type="String">String. A prefix to insert at the beginning of the identifier.</param>
	/// <returns type="String">String. A string containing the generated identifier.</returns>
};

MindFusion.Common.Locale.prototype = {
	fromJson: function(dateSettingsJson) {
		/// <summary>Deserializes the locale from a JSON string.</summary>
		/// <param name="dateSettingsJson" type="String">String. A string containing data for the date settings.</param>
	}
};
MindFusion.Common.Locale.__class = true;

MindFusion.Common.Locale.default = function() {
	/// <summary>Returns a default Locale object.</summary>
	/// <returns type="Locale">Locale. A locale object with default settings.</returns>
};

MindFusion.Common.NotifyCollectionChangedAction.prototype = {
};
MindFusion.Common.NotifyCollectionChangedAction.__class = true;

MindFusion.Common.NotifyCollectionChangedEventArgs.prototype = {
};
MindFusion.Common.NotifyCollectionChangedEventArgs.__class = true;

MindFusion.Common.NotifyCollectionChangingEventArgs.prototype = {
};
MindFusion.Common.NotifyCollectionChangingEventArgs.__class = true;

MindFusion.Common.PropertyEventArgs.prototype = {
};
MindFusion.Common.PropertyEventArgs.__class = true;

MindFusion.Common.UIControl.prototype = {
	draw: function() {
		/// <summary>Draws the UIControl.</summary>
		/// <returns type="HTMLElement">HTMLElement. The control DOM element.</returns>
	}
};
MindFusion.Common.UIControl.__class = true;

MindFusion.Common.Unit.prototype = {
	toString: function() {
		/// <summary>Returns a string representation of this Unit.</summary>
		/// <returns type="String">String. The string representation.</returns>
	}
};
MindFusion.Common.Unit.__class = true;

MindFusion.Common.Unit.empty = function() {
	/// <summary>Creates an empty Unit instance.</summary>
	/// <returns type="Unit">Unit. The new Unit.</returns>
};
MindFusion.Common.Unit.parse = function(value) {
	/// <summary>Creates a Unit instance from a string representation.</summary>
	/// <param name="value" type="String">String. The string representation of the unit.</param>
	/// <returns type="Unit">Unit. The new Unit, or null if the string is invalid.</returns>
};
MindFusion.Common.Unit.percentage = function(value) {
	/// <summary>Creates a Unit instance with the specified value and UnitType.Percent.</summary>
	/// <param name="value" type="Number">Number. The value of the unit.</param>
	/// <returns type="Unit">Unit. The new Unit.</returns>
};
MindFusion.Common.Unit.pixel = function(value) {
	/// <summary>Creates a Unit instance with the specified value and UnitType.Pixel.</summary>
	/// <param name="value" type="Number">Number. The value of the unit.</param>
	/// <returns type="Unit">Unit. The new Unit.</returns>
};

MindFusion.Common.UnitType = {
		/// <summary>Specifies a unit of measurement.</summary>
		/// <field name="Percent">The measurement is a percentage relative to the parent element.</field>
		/// <field name="Pixel">The measurement is in pixels.</field>
	Percent: 2,
	Pixel: 1
}
MindFusion.Common.UnitType.__enum = true;

MindFusion.Controls.Alignment = {
	/// <summary>Specifies the alignment of text relative to its layout rectangle.</summary>
	/// <field name="Center">The text is drawn in the center of the layout rectangle.</field>
	/// <field name="Far">The text is drawn in the far corner of the layout rectangle.</field>
	/// <field name="Near">The text is drawn in the near corner of the layout rectangle.</field>
Center: 1,
Far: 2,
Near: 0
}
MindFusion.Controls.Alignment.__enum = true;

MindFusion.Controls.CancelEventArgs.prototype = {
};
MindFusion.Controls.CancelEventArgs.__class = true;

MindFusion.Controls.Canvas.prototype = {
dispose: function() {
	/// <summary>Overrides Disposable.dispose</summary>
},
invalidate: function(rect, force) {
	/// <summary>Invalidates the canvas or a region of the canvas, causing it to be repainted.</summary>
	/// <param name="rect" type="Rect" optional="true">Optional. Rect. A Rect instance specifying the region that should be repainted. If not specified, the whole diagram will be repainted.</param>
	/// <param name="force" type="Boolean" optional="true">Optional. Boolean. true to force redraw even if currently painting, or false otherwise.</param>
},
repaint: function(printOptions) {
	/// <summary>Repaints the canvas.</summary>
	/// <param name="printOptions" type="Object" optional="true">Optional. Object. For internal use.</param>
},
addEventListener: function(eventName, handler, element) {
	/// <summary>Registers a single event listener on the instance. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that will handle the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
raiseEvent: function(eventName, args, element) {
	/// <summary>Raises an event. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event to raise.</param>
	/// <param name="args" type="EventArgs">EventArgs. An instance of type EventArgs that holds data for the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
removeEventListener: function(eventName, handler, element) {
	/// <summary>Removes a single event listener attached to the instance. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that handles the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
}
};
MindFusion.Controls.Canvas.__class = true;

MindFusion.Controls.CanvasControl.prototype = {
clientToDoc: function(point) {
	/// <summary>Transforms a point from client to document coordinates.</summary>
	/// <param name="point" type="Point">Point. The point to transform.</param>
	/// <returns type="Point">Point. The transformed point.</returns>
},
docToClient: function(point) {
	/// <summary>Transforms a point from document to client coordinates.</summary>
	/// <param name="point" type="Point">Point. The point to transform.</param>
	/// <returns type="Point">Point. The transformed point.</returns>
},
addEventListener: function(eventName, handler, element) {
	/// <summary>Registers a single event listener on the instance. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that will handle the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
raiseEvent: function(eventName, args, element) {
	/// <summary>Raises an event. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event to raise.</param>
	/// <param name="args" type="EventArgs">EventArgs. An instance of type EventArgs that holds data for the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
removeEventListener: function(eventName, handler, element) {
	/// <summary>Removes a single event listener attached to the instance. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that handles the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
registerForSubmit: function(id) {
	/// <summary>Registers an onsubmit handler for the Control's parent html form to flush postback data. Inherited from Control.</summary>
	/// <param name="id" type="String">String. The id of the hidden field to flush the data to.</param>
},
};
MindFusion.Controls.CanvasControl.__class = true;

MindFusion.Controls.CanvasControl.addHandlers = function() {
/// <summary>Adds an event listener to a DOM element. Inherited from Control.</summary>
};
MindFusion.Controls.CanvasControl.clearHandlers = function() {
/// <summary>Removes all event listeners from a DOM element. Inherited from Control.</summary>
};
MindFusion.Controls.CanvasControl.fromJson = function() {
/// <summary>Constructs a JavaScript object from a JSON string. Inherited from Control.</summary>
/// <returns type="Object">Object. object The corresponding to the given JSON text.</returns>
};
MindFusion.Controls.CanvasControl.toJson = function(object) {
/// <summary>Converts a JavaScript object to a JSON string. Inherited from Control.</summary>
/// <param name="object" type="Object">Object. The object to stringify.</param>
/// <returns type="String">String. The JSON string.</returns>
};

MindFusion.Controls.Control.prototype = {
registerForSubmit: function(id) {
	/// <summary>Registers an onsubmit handler for the Control's parent html form to flush postback data.</summary>
	/// <param name="id" type="String">String. The id of the hidden field to flush the data to.</param>
},
addEventListener: function(eventName, handler, element) {
	/// <summary>Registers a single event listener on the instance. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that will handle the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
raiseEvent: function(eventName, args, element) {
	/// <summary>Raises an event. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event to raise.</param>
	/// <param name="args" type="EventArgs">EventArgs. An instance of type EventArgs that holds data for the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
removeEventListener: function(eventName, handler, element) {
	/// <summary>Removes a single event listener attached to the instance. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that handles the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
}
};
MindFusion.Controls.Control.__class = true;

MindFusion.Controls.Control.addHandlers = function() {
/// <summary>Adds an event listener to a DOM element.</summary>
};
MindFusion.Controls.Control.clearHandlers = function() {
/// <summary>Removes all event listeners from a DOM element.</summary>
};
MindFusion.Controls.Control.fromJson = function() {
/// <summary>Constructs a JavaScript object from a JSON string.</summary>
/// <returns type="Object">Object. object The corresponding to the given JSON text.</returns>
};
MindFusion.Controls.Control.toJson = function(object) {
/// <summary>Converts a JavaScript object to a JSON string.</summary>
/// <param name="object" type="Object">Object. The object to stringify.</param>
/// <returns type="String">String. The JSON string.</returns>
};

MindFusion.Controls.Disposable.prototype = {
addEventListener: function(eventName, handler, element) {
	/// <summary>Registers a single event listener on the instance.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that will handle the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
raiseEvent: function(eventName, args, element) {
	/// <summary>Raises an event.</summary>
	/// <param name="eventName" type="String">String. The name of the event to raise.</param>
	/// <param name="args" type="EventArgs">EventArgs. An instance of type EventArgs that holds data for the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
removeEventListener: function(eventName, handler, element) {
	/// <summary>Removes a single event listener attached to the instance.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that handles the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
}
};
MindFusion.Controls.Disposable.__class = true;

MindFusion.Controls.DomUtils.prototype = {
};
MindFusion.Controls.DomUtils.__class = true;

MindFusion.Controls.DomUtils.formatString = function() {
/// <summary>Formats the specified string according to the specified parameters.</summary>
};
MindFusion.Controls.DomUtils.getBounds = function(element, parent, includeScroll) {
/// <summary>Gets the bounds of the specified element.</summary>
/// <param name="element" type="HTMLElement">HTMLElement. The element to check.</param>
/// <param name="parent" type="HTMLElement" optional="true">Optional. HTMLElement. The parent of the element. If supplied, the returned bounds will be relative to the parent element bounds.</param>
/// <param name="includeScroll" type="Boolean" optional="true">Optional. Boolean. For internal use.</param>
/// <returns type="Rect">Rect. The bounding rectangle.</returns>
};
MindFusion.Controls.DomUtils.getElementAttributes = function() {
/// <summary>Gets an object containing element attributes that have values.</summary>
};
MindFusion.Controls.DomUtils.HTMLtoXHTML = function(html) {
/// <summary>Converts HTML to XHMTL.</summary>
/// <param name="html" type="String">String. The HTML to convert.</param>
/// <returns type="String">String. The resulting XHTML.</returns>
};
MindFusion.Controls.DomUtils.loadImageList = function(images) {
/// <summary>Loads the images from the specified list of image url-s.</summary>
/// <param name="images" type="Array">Array. An array of image url-s.</param>
/// <returns type="Promise">Promise. Promise object contaning an array of images in base64 format.</returns>
};
MindFusion.Controls.DomUtils.setBounds = function(element, bounds) {
/// <summary>Sets the bounds of the specified element.</summary>
/// <param name="element" type="HTMLElement">HTMLElement. The element.</param>
/// <param name="bounds" type="Rect">Rect. The bounding rectangle.</param>
};
MindFusion.Controls.DomUtils.setSize = function(element, size) {
/// <summary>Sets the size of the specified element.</summary>
/// <param name="element" type="HTMLElement">HTMLElement. The element.</param>
/// <param name="size" type="Size">Size. The new size.</param>
};
MindFusion.Controls.DomUtils.toDataUrl = function(url, callback) {
/// <summary>Converts an image to base64 string.</summary>
/// <param name="url" type="String">String. The url of the image.</param>
/// <param name="callback" type="function">function. The callback function.</param>
/// <returns type="String">String. The base64-encoded string, representing the image.</returns>
};

MindFusion.Controls.EventArgs.prototype = {
};
MindFusion.Controls.EventArgs.__class = true;

MindFusion.Controls.Events.prototype = {
};
MindFusion.Controls.Events.__class = true;

MindFusion.Controls.MouseButton = {
	/// <summary>Specifies which button was pressed to trigger the event.</summary>
	/// <field name="Auxiliary">Auxiliary button pressed, usually the wheel button or the middle button.</field>
	/// <field name="Fifth">Fifth button, typically the Browser Forward button.</field>
	/// <field name="Fourth">Fourth button, typically the Browser Back button.</field>
	/// <field name="Main">Main button pressed, usually the left button or the un-initialized state.</field>
	/// <field name="Secondary">Secondary button pressed, usually the right button.</field>
Auxiliary: 1,
Fifth: 4,
Fourth: 3,
Main: 0,
Secondary: 2
}
MindFusion.Controls.MouseButton.__enum = true;

MindFusion.Controls.MouseCursors = {
	/// <summary>Specifies the type of the mouse cursor.</summary>
}
MindFusion.Controls.MouseCursors.__enum = true;

MindFusion.Controls.TickPosition = {
	/// <summary>Specifies the position of trackbar ticks.</summary>
	/// <field name="Both">Ticks are rendered on both sides of the trackbar.</field>
	/// <field name="Left">Ticks are rendered on the left side of the trackbar.</field>
	/// <field name="None">There are no ticks rendered.</field>
	/// <field name="Right">Ticks are rendered on the right side of the trackbar.</field>
Both: 3,
Left: 1,
None: 0,
Right: 2
}
MindFusion.Controls.TickPosition.__enum = true;

MindFusion.Controls.ZoomControl.prototype = {
addEventListener: function(eventName, handler, element) {
	/// <summary>Registers a single event listener on the instance. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that will handle the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
raiseEvent: function(eventName, args, element) {
	/// <summary>Raises an event. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event to raise.</param>
	/// <param name="args" type="EventArgs">EventArgs. An instance of type EventArgs that holds data for the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
removeEventListener: function(eventName, handler, element) {
	/// <summary>Removes a single event listener attached to the instance. Inherited from Disposable.</summary>
	/// <param name="eventName" type="String">String. The name of the event.</param>
	/// <param name="handler" type="Method">Method. Represents the method that handles the event specified with eventName.</param>
	/// <param name="element" type="Object" optional="true">Optional. Object. For internal use.</param>
},
registerForSubmit: function(id) {
	/// <summary>Registers an onsubmit handler for the Control's parent html form to flush postback data. Inherited from Control.</summary>
	/// <param name="id" type="String">String. The id of the hidden field to flush the data to.</param>
},
clientToDoc: function(point) {
	/// <summary>Transforms a point from client to document coordinates. Inherited from CanvasControl.</summary>
	/// <param name="point" type="Point">Point. The point to transform.</param>
	/// <returns type="Point">Point. The transformed point.</returns>
},
docToClient: function(point) {
	/// <summary>Transforms a point from document to client coordinates. Inherited from CanvasControl.</summary>
	/// <param name="point" type="Point">Point. The point to transform.</param>
	/// <returns type="Point">Point. The transformed point.</returns>
}
};
MindFusion.Controls.ZoomControl.__class = true;

MindFusion.Controls.ZoomControl.create = function(element) {
/// <summary>Creates and initializes a new ZoomControl from the specified element. This method is static and can be called without creating an instance of the class.</summary>
/// <param name="element" type="HTMLCanvasElement">HTMLCanvasElement. The DOM element that the zoomControl should be attached to.</param>
/// <returns type="ZoomControl">A ZoomControl object that represents the newly created zoom control.</returns>
};
MindFusion.Controls.ZoomControl.find = function(id) {
/// <summary>Returns the specified ZoomControl object. This member is static and can be invoked without creating an instance of the class.</summary>
/// <param name="id" type="String">String. The id of the ZoomControl's DOM element.</param>
/// <returns type="ZoomControl">A ZoomControl object with the specified id, if found, or&#160;null otherwise.</returns>
};
MindFusion.Controls.ZoomControl.addHandlers = function() {
/// <summary>Adds an event listener to a DOM element. Inherited from Control.</summary>
};
MindFusion.Controls.ZoomControl.clearHandlers = function() {
/// <summary>Removes all event listeners from a DOM element. Inherited from Control.</summary>
};
MindFusion.Controls.ZoomControl.fromJson = function() {
/// <summary>Constructs a JavaScript object from a JSON string. Inherited from Control.</summary>
/// <returns type="Object">Object. object The corresponding to the given JSON text.</returns>
};
MindFusion.Controls.ZoomControl.toJson = function(object) {
/// <summary>Converts a JavaScript object to a JSON string. Inherited from Control.</summary>
/// <param name="object" type="Object">Object. The object to stringify.</param>
/// <returns type="String">String. The JSON string.</returns>
};

MindFusion.Drawing.Border3D.prototype = {
};
MindFusion.Drawing.Border3D.__class = true;

MindFusion.Drawing.Component.prototype = {
};
MindFusion.Drawing.Component.__class = true;

MindFusion.Drawing.ComponentBase.prototype = {
};
MindFusion.Drawing.ComponentBase.__class = true;

MindFusion.Drawing.Container.prototype = {
};
MindFusion.Drawing.Container.__class = true;

MindFusion.Drawing.DashStyle = {
		/// <summary>Specifies the dash pattern of lines.</summary>
		/// <field name="Custom">Custom pattern.</field>
		/// <field name="Dash">Draw dashed line.</field>
		/// <field name="DashDot">Draw dash-dot pattern.</field>
		/// <field name="DashDotDot">Draw dash-dot-dot pattern.</field>
		/// <field name="Dot">Draw dotted line.</field>
		/// <field name="Solid">Draw solid line.</field>
	Custom: 5,
	Dash: 1,
	DashDot: 3,
	DashDotDot: 4,
	Dot: 2,
	Solid: 0
}
MindFusion.Drawing.DashStyle.__enum = true;

MindFusion.Drawing.DrawingUtils.prototype = {
};
MindFusion.Drawing.DrawingUtils.__class = true;

MindFusion.Drawing.DrawingUtils.approximateBezier = function(points, quality, start) {
	/// <summary>Approximates a Bezier curve with the given quality and by a series of line segments.</summary>
	/// <param name="points" type="Array">Array. A list of Bezier control points.</param>
	/// <param name="quality" type="Number">Number. Specifies the approximation quality.</param>
	/// <param name="start" type="Number">Number. Specifies the start point index.</param>
	/// <returns type="Array">Array. A list of points that approximate the curve as a series of straight line segments.</returns>
};
MindFusion.Drawing.DrawingUtils.checkIntersect = function(point, rect, rad) {
	/// <summary>Checks if the specified rectangle and circle intersect.</summary>
	/// <param name="point" type="Point">Point. The center of the circle.</param>
	/// <param name="rect" type="Rect">Rect. The rectangle.</param>
	/// <param name="rad" type="Number">Number. The radius of the circle.</param>
	/// <returns type="Boolean">Boolean. true if the rectangle and the circle intersect; otherwise, false.</returns>
};
MindFusion.Drawing.DrawingUtils.degrees = function(radians) {
	/// <summary>Converts the specified value from radians to degrees.</summary>
	/// <param name="radians" type="Number">Number. The radians to convert.</param>
	/// <returns type="Number">Number. The converted angle.</returns>
};
MindFusion.Drawing.DrawingUtils.distToPolyline = function() {
	/// <summary>Calculates the shortest distance from the specified point to the specified polyline, also returning the index of the segment the point is closest to.</summary>
};
MindFusion.Drawing.DrawingUtils.distToRectPoint = function(point, rect) {
	/// <summary>Returns the point that lies on the outline of a rectangle and is nearest to the given point.</summary>
	/// <param name="point" type="Point">Point. The point to consider.</param>
	/// <param name="rect" type="Rect">Rect. The rectangle to consider.</param>
	/// <returns type="Number">Number. The nearest point.</returns>
};
MindFusion.Drawing.DrawingUtils.getCenter = function(rect) {
	/// <summary>Returns the center of the specified rectangle.</summary>
	/// <param name="rect" type="Rect">Rect. The rectangle.</param>
	/// <returns type="Point">Point. The center.</returns>
};
MindFusion.Drawing.DrawingUtils.getPointsBounds = function(points) {
	/// <summary>Calculates the bounding rect of the specified polyline.</summary>
	/// <param name="points" type="Array">Array. An array of points.</param>
	/// <returns type="Rect">Rect. The bounding rect.</returns>
};
MindFusion.Drawing.DrawingUtils.getSegmentIntersection = function(p1, p2, p3, p4) {
	/// <summary>Checks whether the segments defined by the specified point pairs intersect and returns the intersection point.</summary>
	/// <param name="p1" type="Point">Point. The start of the first segment.</param>
	/// <param name="p2" type="Point">Point. The end of the first segment.</param>
	/// <param name="p3" type="Point">Point. The start of the second segment.</param>
	/// <param name="p4" type="Point">Point. The end of the second segment.</param>
	/// <returns type="Boolean">Boolean. true if the segments intersect, false if not.</returns>
};
MindFusion.Drawing.DrawingUtils.inflate = function(rect, x, y) {
	/// <summary>Creates and returns an enlarged copy of a Rect instance.</summary>
	/// <param name="rect" type="Rect">Rect. The Rect instance to inflate.</param>
	/// <param name="x" type="Number">Number. The amount to inflate horizontally.</param>
	/// <param name="y" type="Number">Number. The amount to inflate vertically.</param>
	/// <returns type="Rect">Rect. The inflated Rect.</returns>
};
MindFusion.Drawing.DrawingUtils.intersect = function(p1, p2, p3, p4) {
	/// <summary>Determines whether the specified line segments intersect.</summary>
	/// <param name="p1" type="Point">Point. The start of the first line segment.</param>
	/// <param name="p2" type="Point">Point. The end of the first line segment.</param>
	/// <param name="p3" type="Point">Point. The start of the second line segment.</param>
	/// <param name="p4" type="Point">Point. The end of the second line segment.</param>
	/// <returns type="Boolean">Boolean. true if the segments intersect, false if not.</returns>
};
MindFusion.Drawing.DrawingUtils.minDistToRect = function(point, rect) {
	/// <summary>Calculates the minimum distance between a given point and a given rectangle.</summary>
	/// <param name="point" type="Point">Point. The point.</param>
	/// <param name="rect" type="Rectabgle">Rectabgle. The rectangle.</param>
	/// <returns type="Number">Number. The minimum distance.</returns>
};
MindFusion.Drawing.DrawingUtils.pointInCircle = function(point, center, radius) {
	/// <summary>Checks whether the specified circle contains the specified point.</summary>
	/// <param name="point" type="Point">Point. The point to check.</param>
	/// <param name="center" type="Point">Point. The center of the circle.</param>
	/// <param name="radius" type="Number">Number. The radius of the circle.</param>
	/// <returns type="Boolean">Boolean. true if the circle contains the specified point, false if not.</returns>
};
MindFusion.Drawing.DrawingUtils.pointInEllipse = function(point, rect) {
	/// <summary>Checks whether the specified ellipse contains the specified point.</summary>
	/// <param name="point" type="Point">Point. The point to check.</param>
	/// <param name="rect" type="Rect">Rect. The bounds of the ellipse.</param>
	/// <returns type="Boolean">Boolean. true if the ellipse contains the specified point, false if not.</returns>
};
MindFusion.Drawing.DrawingUtils.pointInPolygon = function(point, polygon) {
	/// <summary>Checks whether the specified rectangle contains the specified point.</summary>
	/// <param name="point" type="Point">Point. The point to check.</param>
	/// <param name="polygon" type="Array">Array. An array with the points that define the polygon.</param>
	/// <returns type="Boolean">Boolean. true if the polygon contains the specified point, false if not.</returns>
};
MindFusion.Drawing.DrawingUtils.radians = function(degrees) {
	/// <summary>Converts the specified value from degrees to radians.</summary>
	/// <param name="degrees" type="Number">Number. The degrees to convert.</param>
	/// <returns type="Number">Number. The converted angle.</returns>
};
MindFusion.Drawing.DrawingUtils.unionRects = function(rect1, rect2) {
	/// <summary>Returns the smallest possible rectangle containing both of the specified rectangles.</summary>
	/// <param name="rect1" type="Rect">Rect. The first rectangle.</param>
	/// <param name="rect2" type="Rect">Rect. The second rectangle.</param>
	/// <returns type="Rect">Rect. A Rect instance that represents the union of the specified arguments.</returns>
};

MindFusion.Drawing.Ellipse.prototype = {
	clone: function() {
		/// <summary>Creates a Ellipse object identical to the current object.</summary>
		/// <returns type="Ellipse">The newly created Ellipse object.</returns>
	}
};
MindFusion.Drawing.Ellipse.__class = true;

MindFusion.Drawing.Font.prototype = {
	apply: function(context) {
		/// <summary>Applies the font properties to a CanvasRenderingContext2D drawing object.</summary>
		/// <param name="context" type="CanvasRenderingContext2D">CanvasRenderingContext2D. The CanvasRenderingContext2D drawing object.</param>
	},
	toObject: function() {
		/// <summary>Returns a JSON object describing this font.</summary>
		/// <returns type="Object">Object. The object describing this font.</returns>
	}
};
MindFusion.Drawing.Font.__class = true;

MindFusion.Drawing.Font.fromObject = function() {
	/// <summary>Returns a Font from a JSON object or string describing this font.</summary>
	/// <returns type="Font">Font. The font object.</returns>
};

MindFusion.Drawing.FontStyle = {
		/// <summary>Specifies font style attributes.</summary>
		/// <field name="Bold">Bold text.</field>
		/// <field name="Italic">Italic text.</field>
		/// <field name="Regular">Normal text.</field>
		/// <field name="Strikeout">Striked text.</field>
		/// <field name="Underline">Underlined text.</field>
	Bold: 1,
	Italic: 2,
	Regular: 0,
	Strikeout: 8,
	Underline: 4
}
MindFusion.Drawing.FontStyle.__enum = true;

MindFusion.Drawing.GraphicsUnit.prototype = {
};
MindFusion.Drawing.GraphicsUnit.__class = true;

MindFusion.Drawing.Image.prototype = {
};
MindFusion.Drawing.Image.__class = true;

MindFusion.Drawing.ImageAlign = {
		/// <summary>Specifies the position and alignment of a picture in a node, or that of the background image.</summary>
		/// <field name="BottomCenter">The image is centered horizontally and aligned to the bottom side.</field>
		/// <field name="BottomLeft">The image is aligned to the bottom left corner of the node or the diagram.</field>
		/// <field name="BottomRight">The image is aligned to the bottom right corner of the node or the diagram.</field>
		/// <field name="Center">The image is centered in the node or diagram.</field>
		/// <field name="Fit">The image is resized to fit the size of the object or the component's client area.</field>
		/// <field name="FitBottom">The image is resized to fit the size of the object and aligned to bottom side.</field>
		/// <field name="FitLeft">The image is resized to fit the size of the object and aligned to left side.</field>
		/// <field name="FitRight">The image is resized to fit the size of the object and aligned to right side.</field>
		/// <field name="FitTop">The image is resized to fit the size of the object and aligned to top side.</field>
		/// <field name="MiddleLeft">The image is centered vertically and aligned to the left-hand side.</field>
		/// <field name="MiddleRight">The image is centered vertically and aligned to the right-hand side.</field>
		/// <field name="Stretch">The image is stretched to fill the object or the component's client area.</field>
		/// <field name="Tile">The image is tiled to cover the node or the diagram.</field>
		/// <field name="TopCenter">The image is centered horizontally and aligned to the top side.</field>
		/// <field name="TopLeft">The image is aligned to the top left corner of the node or the diagram.</field>
		/// <field name="TopRight">The image is aligned to the top right corner of the node or the diagram.</field>
	BottomCenter: 9,
	BottomLeft: 5,
	BottomRight: 7,
	Center: 0,
	Fit: 1,
	FitBottom: 15,
	FitLeft: 12,
	FitRight: 14,
	FitTop: 13,
	MiddleLeft: 10,
	MiddleRight: 11,
	Stretch: 2,
	Tile: 3,
	TopCenter: 8,
	TopLeft: 4,
	TopRight: 6
}
MindFusion.Drawing.ImageAlign.__enum = true;

MindFusion.Drawing.LayoutAlignment = {
		/// <summary>Specifies alignment of components.</summary>
		/// <field name="Center">Center alignment.</field>
		/// <field name="Far">Right ot bottom alignment</field>
		/// <field name="Near">Left or top alignment.</field>
		/// <field name="Stretch">Stretch the component.</field>
	Center: 1,
	Far: 2,
	Near: 0,
	Stretch: 3
}
MindFusion.Drawing.LayoutAlignment.__enum = true;

MindFusion.Drawing.LineJoin = {
		/// <summary>Specifies how to join consecutive line or curve segments in a figure.</summary>
		/// <field name="Bevel">Produces a diagonal corner.</field>
		/// <field name="Miter">Produces a sharp corner or a clipped corner, depending on whether the length of the miter exceeds the miter limit.</field>
		/// <field name="Round">Produces a smooth, circular arc between the lines.</field>
	Bevel: 1,
	Miter: 0,
	Round: 2
}
MindFusion.Drawing.LineJoin.__enum = true;

MindFusion.Drawing.Path.prototype = {
	addEllipse: function(x, y, width, height) {
		/// <summary>Adds an ellipse figure to the path.</summary>
		/// <param name="x" type="Number">Number. The x-coordinate of the center of the ellipse.</param>
		/// <param name="y" type="Number">Number. The y-coordinate of the center of the ellipse.</param>
		/// <param name="width" type="Number">Number. The width of the ellipse.</param>
		/// <param name="height" type="Number">Number. The height of the ellipse.</param>
	},
	addRect: function(x, y, width, height) {
		/// <summary>Adds a rectangle figure to the path.</summary>
		/// <param name="x" type="Number">Number. The x-coordinate of the rectangle.</param>
		/// <param name="y" type="Number">Number. The y-coordinate of the rectangle.</param>
		/// <param name="width" type="Number">Number. The width of the rectangle.</param>
		/// <param name="height" type="Number">Number. The height of the rectangle.</param>
	},
	arcTo: function(x, y, radius, startAngle, endAngle, anticlockwise) {
		/// <summary>Draws an arc.</summary>
		/// <param name="x" type="Number">Number. The x-coordinate of the center of the circle.</param>
		/// <param name="y" type="Number">Number. The y-coordinate of the center of the circle.</param>
		/// <param name="radius" type="Number">Number. The radius of the circle</param>
		/// <param name="startAngle" type="Number">Number. The starting angle in radians.</param>
		/// <param name="endAngle" type="Number">Number. The ending angle in radians.</param>
		/// <param name="anticlockwise" type="Boolean">Boolean. Specifies whether the drawing should be counterclockwise or clockwise.</param>
	},
	bezierTo: function(x1, y1, x2, y2, x3, y3) {
		/// <summary>Draws a cubic bezier curve.</summary>
		/// <param name="x1" type="Number">Number. The x-coordinate of the first bezier control point.</param>
		/// <param name="y1" type="Number">Number. The y-coordinate of the first bezier control point.</param>
		/// <param name="x2" type="Number">Number. The x-coordinate of the second bezier control point.</param>
		/// <param name="y2" type="Number">Number. The y-coordinate of the second bezier control point.</param>
		/// <param name="x3" type="Number">Number. The x-coordinate of the ending point.</param>
		/// <param name="y3" type="Number">Number. The y-coordinate of the ending point.</param>
	},
	clone: function() {
		/// <summary>Creates a Path object identical to the current object.</summary>
		/// <returns type="Path">The newly created Path object.</returns>
	},
	close: function() {
		/// <summary>Closes the path.</summary>
	},
	done: function() {
		/// <summary>Ends the path definition.</summary>
	},
	empty: function() {
		/// <summary>Gets a value indicating whether this Path is empty.</summary>
		/// <returns type="Boolean">true if the path does not contain any figures; otherwise, false.</returns>
	},
	getBounds: function() {
		/// <summary>Gets the bounding rect of the path.</summary>
		/// <returns type="Rect">Rect. The bounding rect.</returns>
	},
	init: function() {
		/// <summary>Begins a path or resets the current path.</summary>
	},
	lineTo: function(x, y) {
		/// <summary>Draws a line from the current point to the specified location.</summary>
		/// <param name="x" type="Number">Number. The x-coordinate of the point.</param>
		/// <param name="y" type="Number">Number. The y-coordinate of the point.</param>
	},
	moveTo: function(x, y) {
		/// <summary>Moves the path to the specified location.</summary>
		/// <param name="x" type="Number">Number. The x-coordinate of the point.</param>
		/// <param name="y" type="Number">Number. The y-coordinate of the point.</param>
	},
	quadraticCurveTo: function(x1, y1, x, y) {
		/// <summary>Draws a quadratic bezier curve.</summary>
		/// <param name="x1" type="Number">Number. The x-coordinate of the bezier control point.</param>
		/// <param name="y1" type="Number">Number. The y-coordinate of the bezier control point.</param>
		/// <param name="x" type="Number">Number. The x-coordinate of the ending point.</param>
		/// <param name="y" type="Number">Number. The y-coordinate of the ending point.</param>
	}
};
MindFusion.Drawing.Path.__class = true;

MindFusion.Drawing.Point.prototype = {
	empty: function() {
		/// <summary>Gets a value indicating whether this Point is empty.</summary>
		/// <returns type="Boolean">true if both&#160;x and&#160;y are 0; otherwise, false.</returns>
	},
	equals: function(point) {
		/// <summary>Specifies whether this Point contains the same coordinates as the specified point.</summary>
		/// <param name="point" type="Point" optional="true">Optional. The Point to test.</param>
		/// <returns type="Boolean">true if point is a Point and has the same coordinates as this Point.</returns>
	}
};
MindFusion.Drawing.Point.__class = true;

MindFusion.Drawing.Rect.prototype = {
	bottom: function() {
		/// <summary>Gets the y-coordinate that is the sum of the&#160;y and height values of this Rect object.</summary>
		/// <returns type="Number">The y-coordinate that is the sum of&#160;y and height of this Rect.</returns>
	},
	bottomLeft: function() {
		/// <summary>Gets the bottom-left edge of this Rect object.</summary>
		/// <returns type="Point">The bottom-left edge, which is a Point with&#160;x that is equal to&#160;x and with&#160;y that is the sum of&#160;y and height.</returns>
	},
	bottomRight: function() {
		/// <summary>Gets the bottom-right edge of this Rect object.</summary>
		/// <returns type="Point">The bottom-right edge, which is a Point with&#160;x that is the sum of&#160;x and width and with&#160;y that is the sum of&#160;y and height.</returns>
	},
	center: function() {
		/// <summary>Gets the center of this Rect object.</summary>
		/// <returns type="Point">The center, which is a Point with&#160;x that is the sum of&#160;x and half of width and with&#160;y that is the sum of&#160;y and half of height.</returns>
	},
	clone: function() {
		/// <summary>Creates a Rect object identical to the current object.</summary>
		/// <returns type="Rect">Rect. The newly created Rect object.</returns>
	},
	contains: function(rect) {
		/// <summary>Determines if the rectangular region represented by rect is entirely contained within this Rect object.</summary>
		/// <param name="rect" type="Rect">The Rect to test.</param>
		/// <returns type="Boolean">true if the rectangular region represented by rect is entirely contained within this Rect; otherwise, false.</returns>
	},
	containsPoint: function(point) {
		/// <summary>Determines if the specified point is contained within this Rect object.</summary>
		/// <param name="point" type="Point">Point. The point to check.</param>
		/// <returns type="Boolean">true if point is contained within the Rect; otherwise, false.</returns>
	},
	equals: function(rect) {
		/// <summary>Specifies whether this Rect contains the same coordinates as the specified rectangle.</summary>
		/// <param name="rect" type="Rect">Rect. The Rect to test.</param>
		/// <returns type="Boolean">Boolean. true if rect has the same coordinates as this Rect.</returns>
	},
	intersect: function(rect) {
		/// <summary>Returns a Rect object representing the intersection of the current rectangle with the specified rectangle.</summary>
		/// <param name="rect" type="Rect">Rect. The rectangle to intersect.</param>
		/// <returns type="Rect">A Rect object representing the intersection of the two rectangles.</returns>
	},
	intersectsWith: function(rect) {
		/// <summary>Checks if this Rect intersects with the specified rect.</summary>
		/// <param name="rect" type="Rect">The other Rect.</param>
		/// <returns type="Boolean">true if this Rect and the specified Rect intersect; otherwise, false.</returns>
	},
	isEmpty: function() {
		/// <summary>Gets a value indicating whether this Rect is empty.</summary>
		/// <returns type="Boolean">true if both width and height are 0; otherwise, false.</returns>
	},
	left: function() {
		/// <summary>Gets the x-coordinate of the left edge of this Rect object.</summary>
		/// <returns type="Number">The x-coordinate of the left edge of this Rect object.</returns>
	},
	right: function() {
		/// <summary>Gets the x-coordinate that is the sum of x and width values of this Rect.</summary>
		/// <returns type="Number">The x-coordinate that is the sum of x and width of this rectangle.</returns>
	},
	setCenter: function(point) {
		/// <summary>Sets the center of this Rect object.</summary>
		/// <param name="point" type="Point">The center of this Rect.</param>
	},
	setLocation: function(point) {
		/// <summary>Sets the top-left edge of this Rect object.</summary>
		/// <param name="point" type="Point">The top-left edge of the Rect.</param>
	},
	top: function() {
		/// <summary>Gets the y-coordinate of the top edge of this Rect object.</summary>
		/// <returns type="Number">Number. The y-coordinate of the top edge of this Rect object.</returns>
	},
	topLeft: function() {
		/// <summary>Gets the top-left edge of this Rect.</summary>
		/// <returns type="Point">The top-left edge of this Rect.</returns>
	},
	topMiddle: function() {
		/// <summary>Gets the top-middle of this Rect object.</summary>
		/// <returns type="Point">The top-middle coordinate, which is a Point with x that is the sum of x and half of width and with y equal to y.</returns>
	},
	topRight: function() {
		/// <summary>Gets the top-right edge of this Rect object.</summary>
		/// <returns type="Point">The top-right edge, which is a Point with x that is the sum of x and width and with y equal to y.</returns>
	},
	union: function(rect) {
		/// <summary>Returns a Rect object representing the union of the current rectangle with the specified rectangle.</summary>
		/// <param name="rect" type="Rect">Rect. The rectangle to union.</param>
		/// <returns type="Rect">A Rect object that bounds the union of the two rectangles.</returns>
	}
};
MindFusion.Drawing.Rect.__class = true;

MindFusion.Drawing.Rect.fromLTRB = function(l, t, r, b) {
	/// <summary>Creates a Rect object with the specified edge locations.</summary>
	/// <param name="l" type="Number">Number. The x-coordinate of the upper-left corner of this Rect.</param>
	/// <param name="t" type="Number">Number. The y-coordinate of the upper-left corner of this Rect.</param>
	/// <param name="r" type="Number">Number. The x-coordinate of the lower-right corner of this Rect.</param>
	/// <param name="b" type="Number">Number. The y-coordinate of the lower-right corner of this Rect.</param>
	/// <returns type="Rect">Rect. A rectangle with the specified coordinates.</returns>
};

MindFusion.Drawing.Size.prototype = {
	empty: function() {
		/// <summary>Gets a value indicating whether this Size is empty.</summary>
		/// <returns type="Boolean">Boolean. true if both width and height are 0; otherwise, false.</returns>
	}
};
MindFusion.Drawing.Size.__class = true;

MindFusion.Drawing.StringAlignment = {
		/// <summary>Specifies the alignment of a text string relative to its layout rectangle.</summary>
		/// <field name="Center">The text is drawn in the center of the layout rectangle.</field>
		/// <field name="Far">The text is drawn in the far corner of the layout rectangle.le.</field>
		/// <field name="Near">The text is drawn in the near corner of the layout rectangle.</field>
	Center: 1,
	Far: 2,
	Near: 0
}
MindFusion.Drawing.StringAlignment.__enum = true;

MindFusion.Drawing.StringFormat.prototype = {
};
MindFusion.Drawing.StringFormat.__class = true;

MindFusion.Drawing.Text.prototype = {
	clone: function() {
		/// <summary>Creates a Text object identical to the current object.</summary>
		/// <returns type="Text">The newly created Text object.</returns>
	},
	getBounds: function() {
		/// <summary>Gets a value indicating the bounding rectangle of the text container.</summary>
		/// <returns type="Rect">Rect. The bounding rectangle.</returns>
	},
	setBounds: function(bounds, angle) {
		/// <summary>Sets a value indicating the bounding rectangle of the text container.</summary>
		/// <param name="bounds" type="Rect">Rect. The bounding rectangle.</param>
		/// <param name="angle" type="Number" optional="true">Optional. Number. The rotation angle to be applied to the bounding rectangle.</param>
	}
};
MindFusion.Drawing.Text.__class = true;

MindFusion.Drawing.Thickness.prototype = {
	addToRect: function(rect) {
		/// <summary>Applies the current thickness to the specified rectangle by inflating the rectangle.</summary>
		/// <param name="rect" type="Rect">Rect. The rectangle to inflate.</param>
	},
	applyTo: function(rect) {
		/// <summary>Applies the current thickness to the specified rectangle by deflating the rectangle.</summary>
		/// <param name="rect" type="Rect">Rect. The rectangle to deflate.</param>
	},
	toAbsolute: function() {
		/// <summary>Converts the current thickness to absolute value relative to the specified size.</summary>
	}
};
MindFusion.Drawing.Thickness.__class = true;

MindFusion.Drawing.Vector.prototype = {
};
MindFusion.Drawing.Vector.__class = true;

MindFusion.Drawing.Video.prototype = {
	clone: function() {
		/// <summary>Creates a Video object identical to the current object.</summary>
		/// <returns type="Video"></returns>
	},
	isPlaying: function() {
		/// <summary>Detects if video is playing.</summary>
	},
	pause: function() {
		/// <summary>Pauses the video.</summary>
	},
	play: function() {
		/// <summary>Starts playing the video stream.</summary>
	}
};
MindFusion.Drawing.Video.__class = true;

MindFusion.Drawing.Visibility = {
		/// <summary>Specifies visibility for components.</summary>
		/// <field name="Collapsed">Specifies that the component is hidden, and the space it occupies in the layout is not preserved.</field>
		/// <field name="Hidden">Specifies that the component is hidden, but the space it occupies in the layout is preserved.</field>
		/// <field name="Visible">Specifies that the component is visible.</field>
	Collapsed: 1,
	Hidden: 0,
	Visible: 2
}
MindFusion.Drawing.Visibility.__enum = true;


MindFusion.Keyboard.Key.prototype = {
	send: function() {
		/// <summary>Sends this key as input to focused element.</summary>
	}
};
MindFusion.Keyboard.Key.__class = true;

MindFusion.Keyboard.KeyboardLayout.prototype = {
	addKey: function(content, left, top, width, height) {
		/// <summary>Adds a new key with specified content and position to the layout.</summary>
		/// <param name="content" type="String">A string containing the key's character.</param>
		/// <param name="left" type="Number">A number specifying key's horizontal position.</param>
		/// <param name="top" type="Number">A number specifying key's vertical position.</param>
		/// <param name="width" type="Number">A number specifying key's width.</param>
		/// <param name="height" type="Number">A number specifying key's height.</param>
	},
};
MindFusion.Keyboard.KeyboardLayout.__class = true;

MindFusion.Keyboard.KeyboardLayout.create = function(layoutDef) {
	/// <summary>Creates and initializes a new KeyboardLayout from the specified definition object.</summary>
	/// <param name="layoutDef" type="Object">A JavaScipt layout definition generated by Keyboard Creator tool.</param>
	/// <returns type="MindFusion.Keyboard.KeyboardLayout">A KeyboardLayout object.</returns>
};

MindFusion.Keyboard.KeyboardMode = {
		/// <summary>Identifies keyboard layout modes.</summary>
		/// <field name="Compact">A layout containing only the alpha-numeric block of keys.</field>
		/// <field name="Default">Laptop-like layout containing alpha-numeric and functional keys.</field>
		/// <field name="Extended">Desktop-like layout which also adds a num-pad block.</field>
	Compact: 0,
	Default: 1,
	Extended: 2
}
MindFusion.Keyboard.KeyboardMode.__enum = true;

MindFusion.Keyboard.KeyboardState.prototype = {
};
MindFusion.Keyboard.KeyboardState.__class = true;

MindFusion.Keyboard.Keys = {
		/// <summary>Defines keyboard key codes.</summary>
		/// <field name="A">The A key.</field>
		/// <field name="Add">The + key.</field>
		/// <field name="Alt">The alt modifier key.</field>
		/// <field name="B">The B key.</field>
		/// <field name="C">The C key.</field>
		/// <field name="CapsLock">The caps lock key.</field>
		/// <field name="Control">The ctrl modifier key.</field>
		/// <field name="D">The D key.</field>
		/// <field name="D0">The 0 key.</field>
		/// <field name="D1">The 1 key.</field>
		/// <field name="D2">The 2 key.</field>
		/// <field name="D3">The 3 key.</field>
		/// <field name="D4">The 4 key.</field>
		/// <field name="D5">The 5 key.</field>
		/// <field name="D6">The 6 key.</field>
		/// <field name="D7">The 7 key.</field>
		/// <field name="D8">The 8 key.</field>
		/// <field name="D9">The 9 key.</field>
		/// <field name="Delete">The delete key.</field>
		/// <field name="Divide">The / key.</field>
		/// <field name="Down">The down arrow key.</field>
		/// <field name="E">The E key.</field>
		/// <field name="F">The F key.</field>
		/// <field name="F1">The F1 key.</field>
		/// <field name="F10">The F10 key.</field>
		/// <field name="F11">The F11 key.</field>
		/// <field name="F12">The F12 key.</field>
		/// <field name="F2">The F2 key.</field>
		/// <field name="F3">The F3 key.</field>
		/// <field name="F4">The F4 key.</field>
		/// <field name="F5">The F5 key.</field>
		/// <field name="F6">The F6 key.</field>
		/// <field name="F7">The F7 key.</field>
		/// <field name="F8">The F8 key.</field>
		/// <field name="F9">The F9 key.</field>
		/// <field name="G">The G key.</field>
		/// <field name="H">The H key.</field>
		/// <field name="I">The I key.</field>
		/// <field name="Insert">The insert key.</field>
		/// <field name="J">The J key.</field>
		/// <field name="K">The K key.</field>
		/// <field name="L">The L key.</field>
		/// <field name="Left">The left arrow key.</field>
		/// <field name="M">The M key.</field>
		/// <field name="Multiply">The * key.</field>
		/// <field name="N">The N key.</field>
		/// <field name="NumLock">The num lock key.</field>
		/// <field name="O">The O key.</field>
		/// <field name="P">The P key.</field>
		/// <field name="Q">The Q key.</field>
		/// <field name="R">The R key.</field>
		/// <field name="Right">The right arrow key.</field>
		/// <field name="S">The S key.</field>
		/// <field name="Shift">The shift modifier key.</field>
		/// <field name="Subtract">The - key.</field>
		/// <field name="T">The T key.</field>
		/// <field name="U">The U key.</field>
		/// <field name="Up">The up arrow key.</field>
		/// <field name="V">The V key.</field>
		/// <field name="W">The W key.</field>
		/// <field name="X">The X key.</field>
		/// <field name="Y">The Y key.</field>
		/// <field name="Z">The Z key.</field>
	A: 0,
	Add: 1,
	Alt: 2,
	B: 3,
	C: 4,
	CapsLock: 5,
	Control: 6,
	D: 7,
	D0: 8,
	D1: 9,
	D2: 10,
	D3: 11,
	D4: 12,
	D5: 13,
	D6: 14,
	D7: 15,
	D8: 16,
	D9: 17,
	Delete: 18,
	Divide: 19,
	Down: 20,
	E: 21,
	F: 22,
	F1: 23,
	F10: 24,
	F11: 25,
	F12: 26,
	F2: 27,
	F3: 28,
	F4: 29,
	F5: 30,
	F6: 31,
	F7: 32,
	F8: 33,
	F9: 34,
	G: 35,
	H: 36,
	I: 37,
	Insert: 38,
	J: 39,
	K: 40,
	L: 41,
	Left: 42,
	M: 43,
	Multiply: 44,
	N: 45,
	NumLock: 46,
	O: 47,
	P: 48,
	Q: 49,
	R: 50,
	Right: 51,
	S: 52,
	Shift: 53,
	Subtract: 54,
	T: 55,
	U: 56,
	Up: 57,
	V: 58,
	W: 59,
	X: 60,
	Y: 61,
	Z: 62
}
MindFusion.Keyboard.Keys.__enum = true;

MindFusion.Keyboard.VirtualKeyboard.prototype = {
	addEventListener: function(eventName, handler) {
		/// <summary>Registers an event handler.</summary>
		/// <param name="eventName" type="String">The name of the event to handle.</param>
		/// <param name="handler" type="Function">A function that handles the event.</param>
	},
	attach: function() {
		/// <summary>Control.attach override.</summary>
	},
	detach: function() {
		/// <summary>Control.detach override.</summary>
	},
	draw: function() {
		/// <summary>Control.draw override.</summary>
	},
	sendKey: function(key) {
		/// <summary>Sends the specified key as input to focused element.</summary>
		/// <param name="key" type="Key">The virtual key that should be sent. Use on of the Keys enumeration vlues or instances of the Key class.</param>
	}
};
MindFusion.Keyboard.VirtualKeyboard.__class = true;

MindFusion.Keyboard.VirtualKeyboard.create = function(element) {
	/// <summary>Creates and initializes a new VirtualKeyboard on the specified DOM element. This method is static and can be called without creating an instance of the class.</summary>
	/// <param name="element" type="Object">Object. The DOM element that the keyboard should be attached to.</param>
	/// <returns type="VirtualKeyboard">VirtualKeyboard. A VirtualKeyboard object that represents the newly created keyboard.</returns>
};

