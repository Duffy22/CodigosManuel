JavaScript Virtual Keyboard library, version 1.1

***** ABOUT MINDFUSION.KEYBOARD ***** 

MindFusion JavaScript virtual keyboard is written entirely in JavaScript and extends your application with keyboard functionality similar to that of touch-screen and mobile devices. The library gives you a fast and easy way to implement:

- text input in a keyboardless environment;
- kiosk or POS user interfaces with a limited number of input keys;
- accessibility features for users with mobility impairments;
- rendering of common words for your application as keys in the keyboard;

The API is intuitive to use. Key-press is handled by a special event. Localization is supported in a variety of languages. 

Styling is done through CSS themes. The control is packed with a set of predefined themes. You can edit them or create your own themes from scratch. 

You can choose among three keyboard layout modes � default, extended and compact.

***** VIRTUAL KEYBOARD CREATOR TOOL *****

Run VirtualKeyboardCreator.exe that is found in the download package of the control to start the tool. There you can use one of the keyboard layouts as a template and design your own keyboard. You can add, remove, resize and relocate keys. The result is saved as a *.js file.

***** SOURCE CODE ***** 

A MindFusion.Keyboard license can be purchased with the control's complete source code. The library is being fully developed in JavaScript. 

***** SAMPLES ***** 

~ Custom ~ presents a custom keyboard layout that consists only of the numpad keys.

~ Demo ~ demonstrates the available styling themes, input languages, layout modes and several DOM elements that can receive the input of the keyboard.

~ HiddenKeyboard ~ shows how to show and hide the keyboard on demand, and load different custom layouts.


***** HISTORY *****
version 1.1:
  ES5 and ES6-compatible scripts in distribution
  TypeScript WebPack samples

initial release

- 8 predefined themes
- 6 input languages
- Keypress event
- VirtualKeyboardCreator tool
- Detailed offline and online documentation


***** CONTACT US *****

for any questions you might have about using the control:
support@mindfusion.eu

for administrative and sales information:
sales@mindfusion.eu

our web site:
https://www.mindfusion.eu

telephone for technical support:
(+359) 889 199 729

